import { Category, Listing, OrderItem, Conversation, UserProfile } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'textbooks',
    name: 'Textbooks & Notes',
    iconName: 'BookOpen',
    count: 0
  },
  {
    id: 'electronics',
    name: 'Electronics & Gadgets',
    iconName: 'Laptop',
    count: 0
  },
  {
    id: 'fashion',
    name: 'Fashion & Thrift',
    iconName: 'Shirt',
    count: 0
  },
  {
    id: 'food',
    name: 'Food & Drinks',
    iconName: 'Utensils',
    count: 0
  },
  {
    id: 'hostels',
    name: 'Hostels & Stays',
    iconName: 'Bed',
    count: 0
  },
  {
    id: 'services',
    name: 'Services & Skills',
    iconName: 'Sparkles',
    count: 0
  },
  {
    id: 'transport',
    name: 'Bikes & Transport',
    iconName: 'Bike',
    count: 0
  }
];

export const MASENO_LISTINGS: Listing[] = [];

export const SAMPLE_MASENO_LISTINGS: Listing[] = [
  {
    id: 'maseno-1',
    title: 'Calculus & Analytical Geometry (Maseno MAT 101/102 Exam Series)',
    price: 1500,
    category: 'textbooks',
    condition: 'Good',
    description: 'Clean textbook with solved Maseno University exam papers from 2021-2024. Ideal for first & second year Mathematics, Computing & Engineering students.',
    location: 'Siriba Campus - Millennium Library Steps',
    image: 'https://images.pexels.com/photos/34889792/pexels-photo-34889792.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-faith',
    sellerName: 'Faith Achieng',
    sellerRating: 4.9,
    sellerVerified: true,
    campus: 'Siriba Campus (Main)',
    createdAt: '25 mins ago',
    status: 'active',
    views: 86,
    inquiries: 5
  },
  {
    id: 'maseno-2',
    title: 'Sony WH-CH520 Wireless Bluetooth Headphones',
    price: 3200,
    category: 'electronics',
    condition: 'Like New',
    description: 'Crisp bass, 50hr battery backup. Perfect for quiet study in Millennium Hall. Comes with original Type-C cable.',
    location: 'College Campus - Hall 4 Breezeway',
    image: 'https://images.pexels.com/photos/18311089/pexels-photo-18311089.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-brian',
    sellerName: 'Brian Otieno',
    sellerRating: 4.8,
    sellerVerified: true,
    campus: 'College Campus',
    createdAt: '1 hour ago',
    status: 'active',
    views: 114,
    inquiries: 8
  },
  {
    id: 'maseno-3',
    title: 'Equator Thick Heavy Fleece Varsity Jacket (Navy/Grey - Size L)',
    price: 1350,
    category: 'fashion',
    condition: 'Good',
    description: 'Maseno evenings can get really chilly with the lake breeze. Very warm heavyweight thrift jacket, metallic snap buttons, pristine condition.',
    location: 'Siriba Gate B / Equator Monument',
    image: 'https://images.pexels.com/photos/5965726/pexels-photo-5965726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    sellerId: 'user-thrift',
    sellerName: 'Maseno Thrift Hub',
    sellerRating: 5.0,
    sellerVerified: true,
    campus: 'Siriba Campus (Main)',
    createdAt: '3 hours ago',
    status: 'active',
    views: 142,
    inquiries: 12
  },
  {
    id: 'maseno-4',
    title: 'Casio fx-991EX ClassWiz Scientific Calculator',
    price: 2100,
    category: 'electronics',
    condition: 'Like New',
    description: 'Authentic QR-code verified Casio calculator approved for Maseno University STEM exams. Dual solar and battery power.',
    location: 'Science Complex (TB 5)',
    image: 'https://images.pexels.com/photos/3568521/pexels-photo-3568521.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-kevin',
    sellerName: 'Kevin Kiprop',
    sellerRating: 4.7,
    sellerVerified: true,
    campus: 'Siriba Campus (Main)',
    createdAt: '5 hours ago',
    status: 'active',
    views: 73,
    inquiries: 6
  },
  {
    id: 'maseno-5',
    title: 'Fresh Homemade Swahili Mahamri & Spicy Beef Samosas (Pack of 6)',
    price: 250,
    category: 'food',
    condition: 'Brand New',
    description: 'Prepared fresh every afternoon. Warm spiced minced beef samosas and cardamon mahamri. Free evening delivery to Siriba, College & Sunrise hostels!',
    location: 'Siriba Mess Gate',
    image: 'https://images.pexels.com/photos/5538594/pexels-photo-5538594.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    sellerId: 'user-amina',
    sellerName: 'Amina Bites Maseno',
    sellerRating: 5.0,
    sellerVerified: true,
    campus: 'Siriba Campus (Main)',
    createdAt: 'Today, 11:30 AM',
    status: 'active',
    views: 210,
    inquiries: 19
  },
  {
    id: 'maseno-6',
    title: 'Spacious Self-Contained Bedsitter Room (Dec - April Semester)',
    price: 5500,
    category: 'hostels',
    condition: 'Good',
    description: 'Inside secure compound at Sunrise Hostels near Gate B. Constant borehole running water, individual prepaid power meter, tiled floor, fast Wi-Fi router.',
    location: 'Sunrise Hostels - Gate B Maseno',
    image: 'https://images.pexels.com/photos/40144605/pexels-photo-40144605.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-caretaker',
    sellerName: 'Sunrise Hostels Admin',
    sellerRating: 4.9,
    sellerVerified: true,
    campus: 'Siriba Campus (Main)',
    createdAt: 'Yesterday',
    status: 'active',
    views: 405,
    inquiries: 22
  },
  {
    id: 'maseno-7',
    title: 'Commuter Mountain Bicycle with Carrier & Lock',
    price: 5800,
    category: 'transport',
    condition: 'Good',
    description: 'Perfect for quick movement between Siriba Campus and College Campus across the Kisumu-Busia highway. Shimano 21 gears, good tires.',
    location: 'College Campus Gate / Boda Stage',
    image: 'https://images.pexels.com/photos/2659939/pexels-photo-2659939.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-otieno',
    sellerName: 'Otieno Boda Supplies',
    sellerRating: 4.8,
    sellerVerified: true,
    campus: 'College Campus',
    createdAt: '2 days ago',
    status: 'active',
    views: 98,
    inquiries: 9
  },
  {
    id: 'maseno-8',
    title: 'BEd Curriculum Studies & Education Psychology Printed Notes',
    price: 750,
    category: 'textbooks',
    condition: 'Good',
    description: 'Complete spiral-bound syllabus revision notes for Maseno School of Education. Contains key diagrams, past CATs and summaries.',
    location: 'College Campus - Education Complex',
    image: 'https://images.pexels.com/photos/34299308/pexels-photo-34299308.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-mercy',
    sellerName: 'Mercy Kemunto',
    sellerRating: 4.9,
    sellerVerified: true,
    campus: 'College Campus',
    createdAt: '2 days ago',
    status: 'active',
    views: 62,
    inquiries: 4
  },
  {
    id: 'maseno-9',
    title: 'HP EliteBook 840 G5 Core i5 (8GB RAM / 256GB SSD)',
    price: 24500,
    category: 'electronics',
    condition: 'Like New',
    description: 'Fast laptop, backlit keyboard, 4-5 hours battery life during campus load shedding. Ideal for Computer Science, IT, and Virtual Campus classes.',
    location: 'Varsity Plaza Kisumu / Siriba Cyber',
    image: 'https://images.pexels.com/photos/4533076/pexels-photo-4533076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-dennis',
    sellerName: 'Dennis Kimani',
    sellerRating: 4.9,
    sellerVerified: true,
    campus: 'Kisumu City Campus (Varsity Plaza)',
    createdAt: '3 days ago',
    status: 'active',
    views: 185,
    inquiries: 14
  },
  {
    id: 'maseno-10',
    title: 'Fast Passport Photos, Academic Typing, CV & Assignment Printing',
    price: 100,
    category: 'services',
    condition: 'Brand New',
    description: 'Affordable student rates for Helb printing, course registration printouts, project binding, and internship CV revamp right next to Millennium.',
    location: 'Millennium Complex / SOMU Office',
    image: 'https://images.pexels.com/photos/37793421/pexels-photo-37793421.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    sellerId: 'user-cyber',
    sellerName: 'Maseno Varsity Cyber',
    sellerRating: 5.0,
    sellerVerified: true,
    campus: 'Siriba Campus (Main)',
    createdAt: '4 days ago',
    status: 'active',
    views: 130,
    inquiries: 11
  }
];

export const INITIAL_ORDERS: OrderItem[] = [];

export const INITIAL_CONVERSATIONS: Conversation[] = [];

export const DEMO_LISTINGS = MASENO_LISTINGS;

export const DEFAULT_USER_PROFILE: UserProfile = {
  id: 'user-default-1',
  name: 'Ethan Alaine',
  regNumber: 'CI/00842/022',
  university: 'Maseno University',
  campus: 'Main Campus — Maseno Township',
  department: 'School of Computing and Informatics',
  email: 'ethan.alaine@student.maseno.ac.ke',
  phone: '0712 345 678',
  defaultMeetup: 'Main Gate, Maseno',
  bio: 'Second-year BBIT student at Maseno. I sell clean gadgets and thrift finds. Meet-ups at Main Gate or Library Square.',
  isVerified: true,
  verificationRequested: false,
  memberSince: 'September 2023',
  totalDeals: 0,
  rating: 4.9,
  listingsCount: 0,
  savedCount: 0
};

export const CURRENT_USER_PROFILE: UserProfile = DEFAULT_USER_PROFILE;
