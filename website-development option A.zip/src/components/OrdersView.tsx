import React, { useState } from 'react';
import { 
  Image as ImageIcon, 
  ChevronDown, 
  MessageSquare, 
  MapPin, 
  CheckCircle2, 
  XCircle,
  Clock,
  Check
} from 'lucide-react';
import { OrderItem } from '../types';

interface OrdersViewProps {
  orders: OrderItem[];
  onOpenChatWithSeller: (sellerName: string, itemTitle: string) => void;
  onUpdateOrderStatus: (orderId: string, newStatus: OrderItem['status']) => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({
  orders,
  onOpenChatWithSeller,
  onUpdateOrderStatus
}) => {
  const [activeTab, setActiveTab] = useState<'buying' | 'selling'>('buying');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const buyingOrders = orders.filter((o) => o.type === 'buying');
  const sellingOrders = orders.filter((o) => o.type === 'selling');

  const currentTabOrders = activeTab === 'buying' ? buyingOrders : sellingOrders;

  const filteredOrders = currentTabOrders.filter((order) => {
    if (statusFilter === 'all') return true;
    return order.status.toLowerCase() === statusFilter.toLowerCase();
  });

  const getStatusBadge = (status: OrderItem['status']) => {
    switch (status) {
      case 'Cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-stone-100 text-stone-600 border border-stone-200">
            Cancelled
          </span>
        );
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Completed
          </span>
        );
      case 'Accepted':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200">
            Accepted
          </span>
        );
      case 'Pending':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" />
            Pending
          </span>
        );
    }
  };

  return (
    <div className="space-y-8 pt-4 pb-16">
      {/* Title & Subtitle matching Screenshot 10 */}
      <div className="border-b border-stone-200/80 pb-6">
        <h1 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
          Orders &amp; tracking
        </h1>
        <p className="text-stone-500 text-sm mt-1 font-light">
          Follow every request from first message to completed deal.
        </p>
      </div>

      {/* Filter Tabs & Status Dropdown */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Buying vs Selling Tabs */}
        <div className="inline-flex bg-stone-100/90 p-1 rounded-full border border-stone-200/60">
          <button
            onClick={() => setActiveTab('buying')}
            className={`px-5 py-2 rounded-full text-xs sm:text-sm font-medium transition ${
              activeTab === 'buying'
                ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Buying ({buyingOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('selling')}
            className={`px-5 py-2 rounded-full text-xs sm:text-sm font-medium transition ${
              activeTab === 'selling'
                ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Selling ({sellingOrders.length})
          </button>
        </div>

        {/* Status Dropdown */}
        <div className="relative self-start sm:self-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="appearance-none bg-white border border-stone-200 rounded-full px-4 py-2 pr-9 text-xs sm:text-sm text-stone-700 hover:border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#0f382c] cursor-pointer shadow-2xs"
          >
            <option value="all">All status</option>
            <option value="pending">Pending</option>
            <option value="accepted">Accepted</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-stone-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>

      {/* Orders List matching Screenshot 10 */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-3xl border border-stone-200/80 p-12 text-center text-stone-400 text-sm">
            No orders found under "{statusFilter}".
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-3xl border border-stone-200/80 p-5 sm:p-6 transition hover:border-stone-300 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-6"
            >
              {/* Left Side: Thumbnail + Info */}
              <div className="flex items-start gap-4 sm:gap-5">
                {/* Image or placeholder icon */}
                <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl bg-stone-100 border border-stone-200/70 flex items-center justify-center shrink-0 overflow-hidden">
                  {order.image ? (
                    <img
                      src={order.image}
                      alt={order.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <ImageIcon className="w-7 h-7 text-stone-300" />
                  )}
                </div>

                {/* Details */}
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    {getStatusBadge(order.status)}
                    <span className="text-xs text-stone-400">{order.date}</span>
                  </div>

                  <h3 className="font-serif text-lg sm:text-xl font-normal text-stone-900">
                    {order.title}
                  </h3>

                  <p className="text-xs text-stone-600">
                    {activeTab === 'buying' ? (
                      <>
                        Seller: <span className="font-medium text-stone-800">{order.sellerName}</span> · {order.quantity} × KSh {order.unitPrice.toLocaleString()}
                      </>
                    ) : (
                      <>
                        Buyer: <span className="font-medium text-stone-800">{order.buyerName}</span> · {order.quantity} × KSh {order.unitPrice.toLocaleString()}
                      </>
                    )}
                  </p>

                  <div className="flex items-center gap-1 text-xs text-stone-400 pt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-stone-400" />
                    <span>{order.meetupLocation}</span>
                  </div>
                </div>
              </div>

              {/* Right Side: Price + Actions */}
              <div className="flex md:flex-col items-center md:items-end justify-between border-t md:border-t-0 pt-3 md:pt-0 border-stone-100 gap-3">
                <div className="font-serif text-xl sm:text-2xl text-[#143d31] font-normal">
                  KSh {order.totalPrice.toLocaleString()}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onOpenChatWithSeller(activeTab === 'buying' ? order.sellerName : order.buyerName, order.title)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-stone-200 text-stone-700 hover:bg-stone-50 text-xs font-medium transition"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-stone-500" />
                    <span>Chat</span>
                  </button>

                  {/* Status update toggles for testing */}
                  {order.status === 'Pending' && activeTab === 'selling' && (
                    <>
                      <button
                        onClick={() => onUpdateOrderStatus(order.id, 'Accepted')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Accept</span>
                      </button>
                      <button
                        onClick={() => onUpdateOrderStatus(order.id, 'Cancelled')}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-medium transition"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Decline</span>
                      </button>
                    </>
                  )}

                  {order.status === 'Accepted' && (
                    <button
                      onClick={() => onUpdateOrderStatus(order.id, 'Completed')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#0f382c] hover:bg-[#144838] text-white text-xs font-medium transition"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Delivered</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Safety Notice Card */}
      <div className="bg-emerald-50/50 border border-emerald-200/80 rounded-3xl p-5 sm:p-6 text-stone-700 text-xs sm:text-sm leading-relaxed flex items-start gap-4">
        <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-emerald-950 block mb-0.5">
            Safe Maseno Trading Guidelines
          </span>
          Always meet in well-lit public campus locations (e.g. Millennium Library steps, Siriba Mess, or College Campus foyer). Inspect textbooks and test electronic gadgets with campus power sockets before completing M-Pesa payments.
        </div>
      </div>
    </div>
  );
};
