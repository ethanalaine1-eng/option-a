import React, { useState } from 'react';
import { Send, CheckCircle2, MapPin, MessageSquare } from 'lucide-react';
import { Conversation, ChatMessage } from '../types';

interface MessagesViewProps {
  conversations: Conversation[];
  activeConvId?: string;
  onSendMessage: (convId: string, text: string) => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({
  conversations,
  activeConvId,
  onSendMessage
}) => {
  const [selectedId, setSelectedId] = useState<string>(
    activeConvId || (conversations[0]?.id ?? '')
  );
  const [inputText, setInputText] = useState('');

  const activeConv = conversations.find((c) => c.id === selectedId) || conversations[0];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeConv) return;
    onSendMessage(activeConv.id, inputText.trim());
    setInputText('');
  };

  const handleQuickPrompt = (prompt: string) => {
    if (!activeConv) return;
    onSendMessage(activeConv.id, prompt);
  };

  return (
    <div className="space-y-6 pt-4 pb-16">
      <div className="border-b border-stone-200/80 pb-6">
        <h1 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
          Messages
        </h1>
        <p className="text-stone-500 text-sm mt-1 font-light">
          Chat directly with buyers and campus sellers in real time.
        </p>
      </div>

      {conversations.length === 0 ? (
        <div className="bg-white rounded-3xl border border-stone-200/80 p-16 text-center text-stone-400">
          <MessageSquare className="w-10 h-10 mx-auto text-stone-300 mb-3" />
          <h3 className="font-serif text-xl text-stone-700">No messages yet</h3>
          <p className="text-xs text-stone-400 mt-1">Start a conversation from any listing or order.</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-stone-200/80 overflow-hidden shadow-2xs grid grid-cols-1 md:grid-cols-12 min-h-[550px]">
          {/* Left: Conversations list */}
          <div className="md:col-span-4 border-r border-stone-200/80 flex flex-col bg-stone-50/40">
            <div className="p-4 border-b border-stone-200/80 font-medium text-xs text-stone-500 uppercase tracking-wider">
              Conversations ({conversations.length})
            </div>
            <div className="overflow-y-auto divide-y divide-stone-100 flex-1 max-h-[500px]">
              {conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setSelectedId(conv.id)}
                  className={`w-full p-4 text-left transition flex items-start gap-3 ${
                    selectedId === conv.id
                      ? 'bg-white border-l-4 border-[#0f382c] shadow-2xs'
                      : 'hover:bg-stone-50/80'
                  }`}
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-100/70 text-[#0f382c] font-semibold text-xs flex items-center justify-center shrink-0">
                    {conv.participantName.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-xs sm:text-sm text-stone-900 truncate">
                        {conv.participantName}
                      </span>
                      <span className="text-[11px] text-stone-400 shrink-0">
                        {conv.lastMessageTime}
                      </span>
                    </div>
                    <div className="text-[11px] text-emerald-800 font-medium truncate mt-0.5">
                      {conv.itemTitle}
                    </div>
                    <p className="text-xs text-stone-500 truncate mt-1">
                      {conv.lastMessage}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Right: Active Chat Window */}
          {activeConv ? (
            <div className="md:col-span-8 flex flex-col justify-between bg-white">
              {/* Chat Header */}
              <div className="p-4 border-b border-stone-200/80 flex items-center justify-between bg-white">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-stone-100 text-[#0f382c] flex items-center justify-center font-bold text-xs">
                    {activeConv.participantName.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 font-medium text-sm text-stone-900">
                      <span>{activeConv.participantName}</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    </div>
                    <div className="text-[11px] text-stone-400">
                      {activeConv.participantRole} · About: <span className="text-stone-700 font-medium">{activeConv.itemTitle}</span> (KSh {activeConv.itemPrice.toLocaleString()})
                    </div>
                  </div>
                </div>

                <div className="hidden sm:flex items-center gap-1 text-xs text-stone-500 bg-stone-50 px-3 py-1.5 rounded-full border border-stone-200">
                  <MapPin className="w-3.5 h-3.5 text-stone-400" />
                  <span>Campus Safe Meeting Spot</span>
                </div>
              </div>

              {/* Chat Messages */}
              <div className="p-4 sm:p-6 space-y-3 overflow-y-auto max-h-[380px] min-h-[280px]">
                {activeConv.messages.map((msg: ChatMessage) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-xs sm:text-sm leading-relaxed ${
                        msg.isMe
                          ? 'bg-[#0f382c] text-white rounded-br-none shadow-2xs'
                          : 'bg-stone-100 text-stone-800 rounded-bl-none'
                      }`}
                    >
                      <p>{msg.text}</p>
                      <div
                        className={`text-[10px] mt-1 text-right ${
                          msg.isMe ? 'text-emerald-200/70' : 'text-stone-400'
                        }`}
                      >
                        {msg.timestamp}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Prompts */}
              <div className="px-4 py-2 bg-stone-50/60 border-t border-stone-100 flex items-center gap-2 overflow-x-auto text-[11px] text-stone-600">
                <span className="text-stone-400 shrink-0">Quick ask:</span>
                <button
                  onClick={() => handleQuickPrompt('Is this item still available?')}
                  className="px-2.5 py-1 bg-white hover:bg-stone-100 rounded-full border border-stone-200 shrink-0 transition"
                >
                  Still available?
                </button>
                <button
                  onClick={() => handleQuickPrompt('Can we meet at the campus library around 2pm?')}
                  className="px-2.5 py-1 bg-white hover:bg-stone-100 rounded-full border border-stone-200 shrink-0 transition"
                >
                  Meet at Library?
                </button>
                <button
                  onClick={() => handleQuickPrompt('Would you accept cash on pickup or M-Pesa?')}
                  className="px-2.5 py-1 bg-white hover:bg-stone-100 rounded-full border border-stone-200 shrink-0 transition"
                >
                  Payment via M-Pesa
                </button>
              </div>

              {/* Message Input Form */}
              <form onSubmit={handleSend} className="p-4 border-t border-stone-200/80 bg-white flex items-center gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Reply to ${activeConv.participantName}...`}
                  className="flex-1 px-4 py-2.5 bg-stone-50 border border-stone-200 rounded-full text-xs sm:text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:border-stone-400 focus:bg-white"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="p-2.5 bg-[#0f382c] hover:bg-[#144838] disabled:opacity-50 text-white rounded-full transition shadow-xs"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          ) : (
            <div className="md:col-span-8 flex items-center justify-center text-stone-400 p-8">
              Select a conversation to start chatting.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
