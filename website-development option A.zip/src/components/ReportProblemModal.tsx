import React, { useState } from 'react';
import { X, ShieldAlert, CheckCircle2, Send, AlertTriangle } from 'lucide-react';

interface ReportProblemModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportProblemModal: React.FC<ReportProblemModalProps> = ({
  isOpen,
  onClose
}) => {
  const [reportType, setReportType] = useState('Suspicious item / Counterfeit');
  const [itemOrSeller, setItemOrSeller] = useState('');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center font-bold">
              <ShieldAlert className="w-5 h-5 text-rose-700" />
            </div>
            <div>
              <h2 className="font-serif text-lg text-stone-900 font-medium">
                Report a Problem
              </h2>
              <p className="text-[11px] text-stone-400">Maseno University Comrade Safety Desk</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-10 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-serif text-2xl text-stone-900">
              Report Received
            </h3>
            <p className="text-xs text-stone-500 max-w-xs mx-auto">
              Thank you for keeping Soko Maseno safe. Our moderation team and SOMU safety rep will review this within 1 hour.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="bg-rose-50/70 border border-rose-200/60 rounded-2xl p-4 text-xs text-rose-950 space-y-1">
              <div className="font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-700" />
                <span>Zero Tolerance on Scams &amp; Harassment</span>
              </div>
              <p className="text-stone-600 leading-relaxed">
                We strictly investigate fake bedsitter listings, non-existent electronics, and off-campus fraudsters targeting Maseno comrades.
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Issue Category *
              </label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 focus:outline-none focus:border-stone-400"
              >
                <option value="Suspicious item / Counterfeit">Suspicious item / Counterfeit</option>
                <option value="Hostel / Bedsitter Scam">Hostel / Bedsitter Scam</option>
                <option value="Seller demanded advance M-Pesa before meeting">Seller demanded advance M-Pesa before meeting</option>
                <option value="Inappropriate behavior / Harassment">Inappropriate behavior / Harassment</option>
                <option value="Academic dishonesty / Prohibited item">Academic dishonesty / Prohibited item</option>
                <option value="Other concern">Other concern</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Item Title or Seller Name (if known)
              </label>
              <input
                type="text"
                placeholder="e.g. Bedsitter at Sunrise Gate B or Seller Brian"
                value={itemOrSeller}
                onChange={(e) => setItemOrSeller(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                What happened? (Details) *
              </label>
              <textarea
                required
                rows={3}
                placeholder="Describe what occurred, any phone numbers involved, or meetup location..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-full border border-stone-200 text-stone-600 text-xs font-medium hover:bg-stone-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-6 py-2 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-xs font-medium shadow-xs cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Report</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
