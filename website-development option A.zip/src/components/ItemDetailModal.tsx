import React, { useState } from 'react';
import { X, CheckCircle2, MapPin, MessageSquare, ShieldCheck, Share2, ShoppingBag } from 'lucide-react';
import { Listing } from '../types';

interface ItemDetailModalProps {
  item: Listing | null;
  onClose: () => void;
  onOpenChat: (sellerName: string, itemTitle: string) => void;
  onRequestBuy: (item: Listing, quantity: number) => void;
}

export const ItemDetailModal: React.FC<ItemDetailModalProps> = ({
  item,
  onClose,
  onOpenChat,
  onRequestBuy
}) => {
  const [quantity, setQuantity] = useState(1);
  const [requestSent, setRequestSent] = useState(false);

  if (!item) return null;

  const handleBuy = () => {
    onRequestBuy(item, quantity);
    setRequestSent(true);
    setTimeout(() => {
      setRequestSent(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        {/* Header Bar */}
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-semibold tracking-wider text-stone-400">
              {item.category.toUpperCase()}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="max-h-[80vh] overflow-y-auto">
          {/* Main Photo */}
          <div className="aspect-[16/10] bg-stone-100 relative overflow-hidden">
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-xs px-4 py-1.5 rounded-full text-sm font-semibold text-stone-900 shadow-md">
              KSh {item.price.toLocaleString()}
            </div>
            <div className="absolute top-4 left-4 bg-[#0f382c] text-white px-3 py-1 rounded-full text-xs font-medium shadow-md">
              {item.condition}
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            {/* Title & Price Header */}
            <div>
              <h2 className="font-serif text-2xl sm:text-3xl text-stone-900 font-normal">
                {item.title}
              </h2>
              <div className="flex items-center gap-2 text-stone-500 text-xs sm:text-sm mt-2">
                <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{item.location} ({item.campus})</span>
                <span className="text-stone-300">·</span>
                <span>Posted {item.createdAt}</span>
              </div>
            </div>

            {/* Seller profile card */}
            <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-emerald-100 text-[#0f382c] flex items-center justify-center font-bold text-sm">
                  {item.sellerName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-sm font-medium text-stone-900">
                    <span>{item.sellerName}</span>
                    {item.sellerVerified && (
                      <span title="Verified student vendor">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-stone-400">
                    Campus Seller · ★ {item.sellerRating.toFixed(1)} rating
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onOpenChat(item.sellerName, item.title);
                }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-white border border-stone-200 rounded-full text-xs font-medium text-stone-700 hover:bg-stone-100 transition shadow-2xs"
              >
                <MessageSquare className="w-3.5 h-3.5 text-stone-500" />
                <span>Chat</span>
              </button>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-stone-400 uppercase tracking-wider">
                Item Description
              </h4>
              <p className="text-sm text-stone-700 leading-relaxed font-light whitespace-pre-line">
                {item.description}
              </p>
            </div>

            {/* Safe campus trading tip */}
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/60 text-xs text-emerald-950">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <span>
                Safe Maseno Trading: Meet in person at well-lit public spots (e.g. Millennium Library steps, Siriba Mess, or College Campus foyer). Inspect condition and verify functionality before paying.
              </span>
            </div>

            {/* Purchase / Request Action Bar */}
            <div className="pt-4 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs font-medium text-stone-600">Quantity:</span>
                <div className="flex items-center border border-stone-200 rounded-xl overflow-hidden bg-stone-50">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 hover:bg-stone-200 text-stone-600 font-medium"
                  >
                    -
                  </button>
                  <span className="px-3 py-1 text-xs font-semibold text-stone-800">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 hover:bg-stone-200 text-stone-600 font-medium"
                  >
                    +
                  </button>
                </div>
                <span className="text-xs text-stone-400 font-light">
                  Total: <strong className="text-stone-900 font-serif text-sm">KSh {(item.price * quantity).toLocaleString()}</strong>
                </span>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  onClick={() => {
                    if (navigator.clipboard) {
                      navigator.clipboard.writeText(window.location.href);
                      alert('Item link copied to clipboard!');
                    }
                  }}
                  className="p-2.5 rounded-full border border-stone-200 text-stone-500 hover:bg-stone-50 transition"
                  title="Share"
                >
                  <Share2 className="w-4 h-4" />
                </button>

                <button
                  onClick={handleBuy}
                  disabled={requestSent}
                  className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-full text-white text-xs sm:text-sm font-medium transition shadow-xs active:scale-95 ${
                    requestSent
                      ? 'bg-emerald-700'
                      : 'bg-[#0f382c] hover:bg-[#154637]'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{requestSent ? 'Order Request Sent!' : 'Request to Buy'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
