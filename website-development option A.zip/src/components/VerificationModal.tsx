import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, Send, School } from 'lucide-react';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestSubmitted?: (req: { name: string; studentId: string; campus: string }) => void;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  onClose,
  onRequestSubmitted
}) => {
  const [studentId, setStudentId] = useState('CI/00842/022');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId.trim()) return;
    
    if (onRequestSubmitted) {
      onRequestSubmitted({
        name: 'Ethan Alaine',
        studentId: studentId.trim(),
        campus: 'Siriba Campus (Main)'
      });
    }

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <h2 className="font-serif text-lg text-stone-900 font-medium">
                Request Verification Badge
              </h2>
              <p className="text-[11px] text-stone-400">Request admin to verify your Maseno Student ID</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-serif text-2xl text-stone-900">
              Request Sent to Admin!
            </h3>
            <p className="text-xs text-stone-600 max-w-xs mx-auto leading-relaxed">
              Your verification request with Maseno Student ID <strong className="font-mono text-stone-900">{studentId}</strong> has been forwarded to the Admin Portal.
            </p>
            <div className="text-[11px] text-emerald-700 font-medium bg-emerald-50 py-1.5 px-3 rounded-full inline-block mt-2">
              Status: Pending Admin Approval
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="flex items-center gap-3 p-3.5 bg-stone-50 border border-stone-200/80 rounded-2xl">
              <div className="w-10 h-10 rounded-xl bg-[#0f382c] text-white flex items-center justify-center font-bold font-serif text-sm">
                EA
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-xs sm:text-sm text-stone-900 truncate">
                  Ethan Alaine
                </div>
                <div className="text-[11px] text-stone-500 flex items-center gap-1">
                  <School className="w-3 h-3 text-emerald-700" />
                  <span>Maseno University · Siriba Campus</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1.5">
                Maseno Student Registration / ID Number *
              </label>
              <input
                type="text"
                required
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                placeholder="e.g. CI/00842/022 or ED/00140/021"
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 font-mono tracking-wide"
              />
              <p className="text-[11px] text-stone-400 mt-1">
                Enter your official student ID to verify your comrade account.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-full border border-stone-200 text-stone-600 text-xs font-medium hover:bg-stone-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-6 py-2 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-xs font-medium shadow-xs cursor-pointer active:scale-95 transition"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Request Admin Verification</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
