import React, { useState } from 'react';
import { X, UserPlus, CheckCircle2 } from 'lucide-react';
import { UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccountCreated: (newUser: UserProfile) => void;
  existingUsers: UserProfile[];
  onSwitchUser: (userId: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAccountCreated,
  existingUsers,
  onSwitchUser
}) => {
  const [tab, setTab] = useState<'create' | 'switch'>('create');
  const [fullName, setFullName] = useState('');
  const [regNumber, setRegNumber] = useState('');
  const [campus, setCampus] = useState('Main Campus — Maseno Township');
  const [phone, setPhone] = useState('');
  const [email] = useState('');
  const [defaultMeetup, setDefaultMeetup] = useState('Main Gate, Maseno');
  const [bio, setBio] = useState('Comrade at Maseno University.');

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      alert('Please enter your full name');
      return;
    }

    const newUser: UserProfile = {
      id: 'user-' + Date.now(),
      name: fullName.trim(),
      regNumber: regNumber.trim() || undefined,
      university: 'Maseno University',
      campus,
      phone: phone.trim() || '0700 000 000',
      email: email.trim() || `${fullName.toLowerCase().replace(/\s+/g, '.')}@student.maseno.ac.ke`,
      defaultMeetup: defaultMeetup.trim() || 'Main Gate, Maseno',
      bio: bio.trim() || 'Maseno University comrade.',
      isVerified: false,
      verificationRequested: false,
      memberSince: 'Today',
      totalDeals: 0,
      rating: 5.0,
      listingsCount: 0,
      savedCount: 0
    };

    onAccountCreated(newUser);
    onClose();
  };

  const getInitials = (n: string) => {
    return n
      .split(' ')
      .map(part => part[0])
      .join('')
      .slice(0, 2)
      .toUpperCase() || 'U';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#0f382c] text-white flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg text-stone-900 font-medium">
                Comrade Account
              </h2>
              <p className="text-[11px] text-stone-400">Create your own profile or switch account</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-6 pt-3 flex items-center gap-3 border-b border-stone-100">
          <button
            type="button"
            onClick={() => setTab('create')}
            className={`pb-2.5 text-xs font-semibold relative transition cursor-pointer ${
              tab === 'create' ? 'text-[#0f382c]' : 'text-stone-400 hover:text-stone-700'
            }`}
          >
            Create New Profile
            {tab === 'create' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0f382c]" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setTab('switch')}
            className={`pb-2.5 text-xs font-semibold relative transition cursor-pointer ${
              tab === 'switch' ? 'text-[#0f382c]' : 'text-stone-400 hover:text-stone-700'
            }`}
          >
            Switch Profile ({existingUsers.length})
            {tab === 'switch' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0f382c]" />
            )}
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {tab === 'create' ? (
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Brian Otieno or Stacy Chebet"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Campus *
                  </label>
                  <select
                    value={campus}
                    onChange={(e) => setCampus(e.target.value)}
                    className="w-full px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                  >
                    <option value="Main Campus — Maseno Township">Main Campus — Maseno Township</option>
                    <option value="Siriba Campus (Main)">Siriba Campus (Main)</option>
                    <option value="College Campus">College Campus</option>
                    <option value="Kisumu City Campus (Varsity Plaza)">Kisumu City Campus (Varsity Plaza)</option>
                    <option value="Odera Akang’o Campus">Odera Akang’o Campus</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Phone / Contact *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 0712 345 678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Maseno Student ID (Optional for badge)
                </label>
                <input
                  type="text"
                  placeholder="e.g. CI/00912/023"
                  value={regNumber}
                  onChange={(e) => setRegNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Default Meetup Location
                </label>
                <input
                  type="text"
                  placeholder="e.g. Millennium Library or Main Gate, Maseno"
                  value={defaultMeetup}
                  onChange={(e) => setDefaultMeetup(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Short Bio
                </label>
                <textarea
                  rows={2}
                  placeholder="Tell buyers what you sell or study..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-full border border-stone-200 text-stone-600 text-xs font-medium hover:bg-stone-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-xs font-medium shadow-xs cursor-pointer"
                >
                  Create &amp; Use Account
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-stone-500 mb-2">
                Click any profile below to immediately switch into their account:
              </p>
              {existingUsers.map((u) => (
                <div
                  key={u.id}
                  onClick={() => {
                    onSwitchUser(u.id);
                    onClose();
                  }}
                  className="p-3.5 rounded-2xl border border-stone-200 hover:border-[#0f382c] hover:bg-emerald-50/30 transition flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#0f382c] text-white flex items-center justify-center font-bold text-sm">
                      {getInitials(u.name)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 font-medium text-stone-900 text-sm">
                        <span>{u.name}</span>
                        {u.isVerified && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        )}
                      </div>
                      <div className="text-xs text-stone-400">
                        {u.campus} · {u.phone}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs text-[#0f382c] font-medium hover:underline">
                    Switch →
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
