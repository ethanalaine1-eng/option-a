import React from 'react';
import { 
  CheckCircle2, 
  Search, 
  ArrowRight,
  BookOpen, 
  Laptop, 
  Shirt, 
  Utensils, 
  Bed, 
  Sparkles, 
  Bike,
  Package,
  Compass,
  ChevronRight,
  MapPin
} from 'lucide-react';
import { Category, Listing } from '../types';

interface HomeViewProps {
  categories: Category[];
  listings: Listing[];
  onSelectCategory: (categoryId: string) => void;
  onSearch: (term: string) => void;
  onNavigateToBrowse: () => void;
  onOpenSellModal: () => void;
  onOpenVerificationModal: () => void;
  onSelectItem: (item: Listing) => void;
}

const MASENO_QUICK_SEARCHES = [
  'Calculus MAT 101',
  'Earphones & Gadgets',
  'Equator Fleece Hoodie',
  'Sunrise Hostels Gate B',
  'Casio fx-991EX'
];

export const HomeView: React.FC<HomeViewProps> = ({
  categories,
  listings,
  onSelectCategory,
  onSearch,
  onNavigateToBrowse,
  onOpenSellModal,
  onOpenVerificationModal,
  onSelectItem
}) => {
  const [heroSearchInput, setHeroSearchInput] = React.useState('');

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearchInput.trim()) {
      onSearch(heroSearchInput.trim());
    }
    onNavigateToBrowse();
  };

  const handleQuickTagClick = (tag: string) => {
    onSearch(tag);
    onNavigateToBrowse();
  };

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className="w-5 h-5 text-[#0f382c]" />;
      case 'Laptop':
        return <Laptop className="w-5 h-5 text-[#0f382c]" />;
      case 'Shirt':
        return <Shirt className="w-5 h-5 text-[#0f382c]" />;
      case 'Utensils':
        return <Utensils className="w-5 h-5 text-[#0f382c]" />;
      case 'Bed':
        return <Bed className="w-5 h-5 text-[#0f382c]" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#0f382c]" />;
      case 'Bike':
        return <Bike className="w-5 h-5 text-[#0f382c]" />;
      default:
        return <Package className="w-5 h-5 text-[#0f382c]" />;
    }
  };

  return (
    <div className="w-full pb-16">
      {/* 1. FULL-WIDTH COVER HERO SECTION (matching screenshot) */}
      <section className="relative w-full min-h-[580px] lg:min-h-[660px] flex items-center bg-stone-900 overflow-hidden">
        {/* Full-width Cover Photo */}
        <div className="absolute inset-0 w-full h-full">
          <img
            src="/hero-cover.jpg"
            alt="Campus Market"
            className="w-full h-full object-cover object-center filter brightness-95"
            onError={(e) => {
              // fallback to hero-market or high-res campus market image
              (e.target as HTMLImageElement).src = "/hero-market.jpg";
            }}
          />
          {/* Dark gradient overlay for ultra-crisp white text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/65 to-black/35" />
          <div className="absolute inset-0 bg-black/25" />
        </div>

        {/* Content over the full-page photo */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-16 sm:py-24">
          <div className="max-w-2xl space-y-6">
            {/* GET VERIFIED BADGE Pill */}
            <button
              onClick={onOpenVerificationModal}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-white/25 bg-black/40 hover:bg-black/60 backdrop-blur-md text-emerald-300 text-xs sm:text-[13px] font-medium shadow-md transition group cursor-pointer"
              title="Click to request admin verification"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-white">GET VERIFIED BADGE — Click to Request Admin Verification</span>
              <ChevronRight className="w-3 h-3 text-emerald-400 opacity-80 group-hover:translate-x-0.5 transition-transform" />
            </button>

            {/* Main Headline matching screenshot: "Your campus market, in your pocket." */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-[4.2rem] leading-[1.1] text-white font-normal tracking-tight drop-shadow-sm">
              Your campus market, in your pocket.
            </h1>

            {/* Subtitle matching screenshot */}
            <p className="text-stone-200 text-base sm:text-xl leading-relaxed font-light drop-shadow-xs max-w-xl">
              Buy and sell textbooks, gadgets, fashion, meals and stays with verified students and local vendors.
            </p>

            {/* Search Bar matching screenshot */}
            <div className="space-y-3 max-w-xl pt-2">
              <form 
                onSubmit={handleHeroSearch}
                className="relative flex items-center bg-white/98 backdrop-blur-md border border-white/40 rounded-full p-1.5 shadow-2xl hover:bg-white transition"
              >
                <div className="flex items-center flex-1 pl-3.5 sm:pl-5">
                  <Search className="w-5 h-5 text-stone-400 mr-2.5 shrink-0" />
                  <input
                    type="text"
                    value={heroSearchInput}
                    onChange={(e) => setHeroSearchInput(e.target.value)}
                    placeholder="Search for a calculus book, earphones..."
                    className="w-full text-sm sm:text-base text-stone-900 placeholder-stone-400 bg-transparent focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-[#0f382c] hover:bg-[#144838] text-white px-6 sm:px-8 py-3 rounded-full text-sm font-medium transition active:scale-95 shadow-md cursor-pointer shrink-0"
                >
                  Search
                </button>
              </form>

              {/* Quick Tags pills */}
              <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-stone-300 pt-1">
                <span className="text-stone-400 flex items-center gap-1 mr-0.5">
                  <Compass className="w-3 h-3 text-stone-300" />
                  Popular:
                </span>
                {MASENO_QUICK_SEARCHES.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => handleQuickTagClick(tag)}
                    className="px-2.5 py-1 bg-black/40 hover:bg-black/60 backdrop-blur-xs text-stone-200 rounded-full border border-white/20 transition cursor-pointer hover:text-white"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Stats row */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-xs sm:text-sm text-stone-300 pt-2 font-normal">
              <button
                onClick={onNavigateToBrowse}
                className="flex items-center gap-1.5 hover:text-white transition group cursor-pointer"
              >
                <span className="font-semibold text-white">{listings.length}</span> listings live
              </button>
              <span className="text-stone-400">·</span>
              <button
                onClick={() => {
                  const el = document.getElementById('browse-categories-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex items-center gap-1.5 hover:text-white transition group cursor-pointer"
              >
                <span className="font-semibold text-white">{categories.length}</span> categories
              </button>
              <span className="text-stone-400">·</span>
              <span className="text-stone-300">Prices in Kenyan shillings (KSh)</span>
            </div>
          </div>
        </div>
      </section>

      {/* REST OF PAGE CONTENT */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20 pt-16">
        {/* 2. BROWSE BY CATEGORY SECTION */}
        <section id="browse-categories-section" className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
            <div>
              <h2 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
                Browse by category
              </h2>
              <p className="text-stone-500 text-sm sm:text-base mt-1 font-light">
                Everything students and local vendors trade in Maseno, organised for quick discovery.
              </p>
            </div>
            <button
              onClick={onNavigateToBrowse}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-stone-700 hover:text-[#0f382c] transition group shrink-0 cursor-pointer"
            >
              <span>See all listings</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* Categories Grid (All 7 Cards Clickable) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className="group text-left bg-white rounded-3xl p-5 border border-stone-200/80 hover:border-emerald-500 hover:shadow-md transition-all duration-200 flex flex-col justify-between min-h-[145px] cursor-pointer hover:-translate-y-0.5"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="w-11 h-11 rounded-2xl bg-emerald-50/70 group-hover:bg-[#0f382c] border border-emerald-100 flex items-center justify-center transition-colors">
                    <div className="group-hover:text-white transition-colors">
                      {getCategoryIcon(cat.iconName)}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-stone-300 group-hover:text-[#0f382c] group-hover:translate-x-1 transition-all" />
                </div>
                <div className="mt-4">
                  <h3 className="font-medium text-stone-900 group-hover:text-[#0f382c] transition text-[15px]">
                    {cat.name}
                  </h3>
                  <span className="text-xs text-stone-400 mt-0.5 block font-light">
                    {cat.count} {cat.count === 1 ? 'listing' : 'listings'}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* 3. JUST LISTED SECTION */}
        <section className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
            <div>
              <h2 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
                Just listed
              </h2>
              <p className="text-stone-500 text-sm sm:text-base mt-1 font-light">
                The newest items on the Maseno campus marketplace.
              </p>
            </div>
            <button
              onClick={onNavigateToBrowse}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-stone-700 hover:text-[#0f382c] transition group shrink-0 cursor-pointer"
            >
              <span>Browse all</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* If listings empty */}
          {listings.length === 0 ? (
            <div className="bg-white rounded-3xl border border-stone-200/80 p-16 text-center">
              <div className="text-stone-500 text-sm sm:text-base font-light">
                No listings yet — be the first to post something.
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {listings.slice(0, 6).map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectItem(item)}
                  className="group cursor-pointer bg-white rounded-3xl border border-stone-200/90 overflow-hidden hover:border-emerald-400 hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
                >
                  <div>
                    <div className="aspect-[4/3] relative bg-stone-100 overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-full text-xs font-semibold text-stone-800 shadow-2xs">
                        KSh {item.price.toLocaleString()}
                      </div>
                      <div className="absolute bottom-3 left-3 bg-[#0f382c]/85 text-white backdrop-blur-xs px-2 py-0.5 rounded-md text-[11px] font-medium">
                        {item.condition}
                      </div>
                    </div>

                    <div className="p-5 space-y-2">
                      <h3 className="font-serif text-lg font-medium text-stone-900 group-hover:text-[#0f382c] transition line-clamp-1">
                        {item.title}
                      </h3>
                      <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  <div className="px-5 pb-5 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                    <div className="flex items-center gap-1 truncate max-w-[170px]">
                      <MapPin className="w-3 h-3 text-stone-400 shrink-0" />
                      <span className="truncate">{item.location}</span>
                    </div>
                    <span className="text-[#0f382c] font-medium group-hover:underline shrink-0">View details</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* 4. CALL TO ACTION BANNER */}
        <section>
          <div className="bg-gradient-to-r from-[#0d3b2e] via-[#114436] to-[#174d3e] rounded-[2.2rem] p-8 sm:p-12 md:p-16 text-white shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="max-w-2xl space-y-6 relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-emerald-200 text-xs">
                <span>Maseno University Free Student Trade</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal leading-tight text-white tracking-tight">
                Have something to sell? Post it in minutes.
              </h2>
              <p className="text-emerald-100/80 text-sm sm:text-base leading-relaxed font-light">
                Students and local vendors list textbooks, gadgets, thrift, food and rooms for free — and buyers nearby in Siriba, College or Kisumu find them the same day.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={onOpenSellModal}
                  className="bg-[#d97706] hover:bg-[#b45309] text-white px-7 sm:px-9 py-3 rounded-full text-sm font-medium transition active:scale-95 shadow-md cursor-pointer"
                >
                  Start selling
                </button>
                <button
                  onClick={onNavigateToBrowse}
                  className="border border-emerald-500/50 hover:bg-emerald-800/40 text-emerald-100 px-7 sm:px-9 py-3 rounded-full text-sm font-medium transition active:scale-95 cursor-pointer"
                >
                  Browse the marketplace
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
