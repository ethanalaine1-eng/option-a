import React from 'react';
import { X, CheckCircle2, School, BookOpen, MapPin, Mail, Calendar, Star, ShieldCheck } from 'lucide-react';
import { UserProfile, Listing } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  userListings: Listing[];
  onGoToStore: () => void;
  onOpenVerificationModal: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  userListings,
  onGoToStore,
  onOpenVerificationModal
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        {/* Header Cover */}
        <div className="relative bg-gradient-to-r from-[#0d382c] to-[#1a5441] p-6 text-white pb-14">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-emerald-200/80 hover:text-white hover:bg-white/10 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="inline-flex items-center gap-1.5 bg-emerald-800/60 border border-emerald-400/30 text-emerald-100 text-xs px-3 py-1 rounded-full mb-2">
            <School className="w-3.5 h-3.5" />
            <span>Maseno University Student Account</span>
          </div>
          <h2 className="font-serif text-2xl font-normal text-white">Student Vendor Profile</h2>
        </div>

        {/* Profile Card Overlay */}
        <div className="px-6 -mt-10 pb-6 space-y-6">
          <div className="flex items-end justify-between">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl bg-white p-1 shadow-lg border-2 border-stone-100">
                <div className="w-full h-full rounded-xl bg-[#0f382c] text-white flex items-center justify-center font-bold text-2xl font-serif">
                  EA
                </div>
              </div>
              <div className="pt-8">
                <div className="flex items-center gap-2">
                  <h3 className="font-serif text-xl font-medium text-stone-900">{profile.name}</h3>
                  {profile.isVerified && (
                    <span title="Verified Maseno Student">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </span>
                  )}
                </div>
                <p className="text-xs text-stone-500 font-mono">{profile.regNumber}</p>
              </div>
            </div>

            <div className="text-right">
              <div className="flex items-center gap-1 text-amber-500 text-sm font-semibold justify-end">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>{profile.rating.toFixed(1)}</span>
              </div>
              <span className="text-[11px] text-stone-400">Trust rating</span>
            </div>
          </div>

          {/* Academic & Campus details */}
          <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200/80 space-y-2.5 text-xs text-stone-700">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-stone-400 shrink-0" />
              <span>{profile.department}</span>
            </div>
            <div className="flex items-center gap-2">
              <School className="w-4 h-4 text-stone-400 shrink-0" />
              <span>{profile.university} — <strong>{profile.campus}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-stone-400 shrink-0" />
              <span>Default meetup: <strong>Millennium Library / Siriba Mess</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-stone-400 shrink-0" />
              <span className="font-mono text-stone-600">{profile.email}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-stone-400 shrink-0" />
              <span>Member since {profile.memberSince} · {profile.totalDeals} campus deals closed</span>
            </div>
          </div>

          {/* Verified status card */}
          {profile.isVerified ? (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 text-emerald-900 font-medium">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <span>Verified with Maseno Student ID #{profile.regNumber}</span>
              </div>
              <span className="text-[11px] bg-emerald-200/70 text-emerald-800 px-2 py-0.5 rounded-full font-semibold">Active</span>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-stone-700">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Maseno ID: <strong className="font-mono text-stone-900">{profile.regNumber}</strong></span>
              </div>
              <button 
                onClick={() => { onClose(); onOpenVerificationModal(); }}
                className="px-3 py-1 bg-[#0f382c] hover:bg-[#154637] text-white rounded-full text-xs font-medium cursor-pointer transition"
              >
                Request Admin Verification
              </button>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex items-center justify-between border-t border-stone-100">
            <button
              onClick={() => { onClose(); onGoToStore(); }}
              className="text-xs font-medium text-[#0f382c] hover:underline"
            >
              Manage My Store ({userListings.length} listings) →
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
