import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, 
  Bell, 
  Plus, 
  User, 
  Store, 
  Package, 
  MessageSquare, 
  ShieldCheck, 
  LogOut,
  CheckCircle2,
  Menu,
  X,
  UserPlus,
  LogIn
} from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenSellModal: () => void;
  onOpenAdminModal: () => void;
  onOpenVerificationModal: () => void;
  onOpenAuthModal: () => void;
  currentUser: UserProfile | null;
  isLoggedIn: boolean;
  onSignOut: () => void;
  unreadCount?: number;
  selectedCampus?: string;
  onSelectCampus?: (campus: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  onOpenSellModal,
  onOpenAdminModal,
  onOpenVerificationModal,
  onOpenAuthModal,
  currentUser,
  isLoggedIn,
  onSignOut,
  unreadCount = 0
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMobileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveTab('browse');
  };

  const getInitials = (n: string) => {
    return n
      .split(' ')
      .map(part => part[0])
      .join('')
      .slice(0, 2)
      .toUpperCase() || 'U';
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-3 sm:gap-4">
        {/* Left: Rebranded Brand Logo Soko Maseno with Store Icon */}
        <div className="flex items-center gap-5 lg:gap-7">
          <button 
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2.5 text-left group focus:outline-none cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-[#0f382c] flex items-center justify-center text-white shadow-xs transition-transform group-hover:scale-105 shrink-0">
              <Store className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-[1.4rem] font-medium tracking-tight text-[#143d31] leading-tight">
                Soko Maseno
              </span>
              <span className="text-[10px] tracking-widest uppercase font-semibold text-[#0f382c]/80">
                MASENO UNIVERSITY
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm">
            <button
              onClick={() => setActiveTab('browse')}
              className={`transition cursor-pointer font-normal ${
                activeTab === 'browse'
                  ? 'text-[#0f382c] font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Browse
            </button>
            <button
              onClick={() => setActiveTab('store')}
              className={`transition cursor-pointer font-normal ${
                activeTab === 'store'
                  ? 'text-[#0f382c] font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              My store
            </button>
            {isLoggedIn && (
              <button
                onClick={() => setActiveTab('profile')}
                className={`transition cursor-pointer font-normal ${
                  activeTab === 'profile'
                    ? 'text-[#0f382c] font-semibold'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Profile
              </button>
            )}
          </nav>
        </div>

        {/* Center: Search input */}
        <div className="flex-1 max-w-md hidden sm:block">
          <form onSubmit={handleSearchSubmit} className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for a calculus book, earphones..."
              className="w-full pl-10 pr-4 py-2 bg-stone-50/70 hover:bg-stone-50 focus:bg-white border border-stone-200/90 rounded-full text-sm text-stone-800 placeholder-stone-400 transition focus:outline-none focus:border-stone-400 focus:ring-2 focus:ring-[#0f382c]/10"
            />
          </form>
        </div>

        {/* Right Actions: + Sell, Messages, Orders, Profile / Login, Notifications, Avatar */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* "+ Sell" button - must be logged in */}
          <button
            onClick={onOpenSellModal}
            className="flex items-center gap-1.5 text-stone-700 hover:text-[#0f382c] px-3 py-1.5 rounded-full text-xs sm:text-sm font-medium transition cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.2]" />
            <span>Sell</span>
          </button>

          {/* Messages link */}
          <button
            onClick={() => setActiveTab('messages')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs sm:text-sm font-medium transition cursor-pointer ${
              activeTab === 'messages' ? 'text-[#0f382c] font-semibold bg-stone-100' : 'text-stone-700 hover:text-stone-900'
            }`}
          >
            <MessageSquare className="w-4 h-4 stroke-[1.8]" />
            <span>Messages</span>
          </button>

          {/* Orders link */}
          <button
            onClick={() => setActiveTab('orders')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs sm:text-sm font-medium transition cursor-pointer ${
              activeTab === 'orders' ? 'text-[#0f382c] font-semibold bg-stone-100' : 'text-stone-700 hover:text-stone-900'
            }`}
          >
            <Package className="w-4 h-4 stroke-[1.8]" />
            <span>Orders</span>
          </button>

          {/* Notifications bell */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-full transition relative focus:outline-none cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-4.5 h-4.5 stroke-[1.8]" />
              {unreadCount > 0 && (
                <span className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Popup */}
            {notificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-stone-200 py-3 z-50 text-stone-800 text-sm animate-in fade-in zoom-in-95">
                <div className="px-4 pb-2 border-b border-stone-100 flex items-center justify-between">
                  <span className="font-semibold text-stone-900">Soko Maseno Alerts</span>
                  <span className="text-xs text-stone-400">0 unread</span>
                </div>
                <div className="py-8 px-4 text-center text-stone-400 text-xs">
                  No notifications yet. You're all caught up!
                </div>
              </div>
            )}
          </div>

          {/* Login or User Avatar */}
          {isLoggedIn && currentUser ? (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="w-9 h-9 rounded-full bg-[#0f382c] text-white hover:bg-[#154637] font-semibold text-xs tracking-wider flex items-center justify-center border border-[#0f382c] transition focus:outline-none focus:ring-2 focus:ring-[#0f382c]/20 cursor-pointer shadow-2xs"
                aria-label="User menu"
              >
                {getInitials(currentUser.name)}
              </button>

              {/* Dropdown Menu */}
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-stone-200/90 py-2.5 z-50 text-stone-800 animate-in fade-in zoom-in-95">
                  <div className="px-4 py-2 border-b border-stone-100 mb-1">
                    <div className="flex items-center gap-1.5 font-semibold text-stone-900 text-sm">
                      <span className="truncate">{currentUser.name}</span>
                      {currentUser.isVerified && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      )}
                    </div>
                    <div className="text-xs text-stone-500 truncate font-mono">
                      {currentUser.email}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setActiveTab('profile');
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-stone-700 hover:bg-stone-50 hover:text-stone-900 transition text-left cursor-pointer"
                  >
                    <User className="w-4 h-4 text-stone-500 stroke-[1.8]" />
                    <span>My profile</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenAuthModal();
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-[#0f382c] font-medium hover:bg-stone-50 transition text-left cursor-pointer"
                  >
                    <UserPlus className="w-4 h-4 text-[#0f382c] stroke-[1.8]" />
                    <span>Create / Switch account</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('store');
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-stone-700 hover:bg-stone-50 hover:text-stone-900 transition text-left cursor-pointer"
                  >
                    <Store className="w-4 h-4 text-stone-500 stroke-[1.8]" />
                    <span>My store</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('orders');
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-stone-700 hover:bg-stone-50 hover:text-stone-900 transition text-left cursor-pointer"
                  >
                    <Package className="w-4 h-4 text-stone-500 stroke-[1.8]" />
                    <span>Orders &amp; tracking</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('messages');
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-stone-700 hover:bg-stone-50 hover:text-stone-900 transition text-left cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4 text-stone-500 stroke-[1.8]" />
                    <span>Messages</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenVerificationModal();
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-stone-700 hover:bg-stone-50 hover:text-stone-900 transition text-left cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 stroke-[1.8]" />
                    <span>Get verified badge</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenAdminModal();
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-stone-700 hover:bg-stone-50 hover:text-stone-900 transition text-left cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4 text-stone-500 stroke-[1.8]" />
                    <span>Administrator portal</span>
                  </button>

                  <div className="border-t border-stone-100 my-1"></div>

                  <button
                    onClick={() => {
                      setDropdownOpen(false);
                      onSignOut();
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-xs sm:text-sm text-rose-600 hover:bg-rose-50 transition text-left cursor-pointer font-medium"
                  >
                    <LogOut className="w-4 h-4 text-rose-500 stroke-[1.8]" />
                    <span>Sign out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('login')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-xs sm:text-sm font-medium shadow-xs transition active:scale-95 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Login / Register</span>
            </button>
          )}

          {/* Hamburger Menu Icon */}
          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-stone-700 hover:text-stone-900 hover:bg-stone-100 rounded-xl transition cursor-pointer"
              aria-label="Navigation Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5 stroke-[2.2]" />
              )}
            </button>

            {/* Hamburger Dropdown Drawer */}
            {mobileMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-stone-200 py-2.5 z-50 text-stone-800 animate-in fade-in zoom-in-95">
                <div className="px-4 py-1.5 text-[11px] font-bold text-stone-400 uppercase tracking-wider">
                  Menu Navigation
                </div>
                <button
                  onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'home' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                >
                  <span>Home</span>
                </button>
                <button
                  onClick={() => { setActiveTab('browse'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'browse' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                >
                  <span>Browse listings</span>
                </button>
                <button
                  onClick={() => { setActiveTab('store'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'store' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                >
                  <span>My store</span>
                </button>
                <button
                  onClick={() => { setActiveTab('orders'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'orders' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                >
                  <span>Orders &amp; tracking</span>
                </button>
                <button
                  onClick={() => { setActiveTab('messages'); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'messages' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                >
                  <span>Messages</span>
                </button>

                {isLoggedIn ? (
                  <button
                    onClick={() => { setActiveTab('profile'); setMobileMenuOpen(false); }}
                    className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'profile' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                  >
                    <span>My profile</span>
                  </button>
                ) : (
                  <button
                    onClick={() => { setActiveTab('login'); setMobileMenuOpen(false); }}
                    className="w-full text-left px-4 py-2 text-xs sm:text-sm text-[#0f382c] font-semibold hover:bg-emerald-50 flex items-center gap-2 cursor-pointer"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Login to Buy or Sell</span>
                  </button>
                )}

                <button
                  onClick={() => { onOpenAdminModal(); setMobileMenuOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-xs sm:text-sm hover:bg-stone-50 flex items-center gap-2.5 cursor-pointer ${activeTab === 'admin' ? 'font-semibold text-[#0f382c]' : 'text-stone-700'}`}
                >
                  <span>Admin portal</span>
                </button>

                <div className="border-t border-stone-100 my-1" />
                <button
                  onClick={() => { onOpenSellModal(); setMobileMenuOpen(false); }}
                  className="w-full text-left px-4 py-2 text-xs sm:text-sm text-emerald-800 font-semibold hover:bg-emerald-50 flex items-center gap-2 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Sell an item</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile search bar */}
      <div className="sm:hidden px-4 pb-3 pt-1 border-t border-stone-100">
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for a calculus book, earphones..."
            className="w-full pl-10 pr-4 py-1.5 bg-stone-50 border border-stone-200 rounded-full text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:border-stone-400"
          />
        </form>
      </div>

      {/* Mobile bottom-like quick tabs */}
      <div className="flex lg:hidden items-center justify-around border-t border-stone-100 py-2 text-xs bg-white text-stone-600">
        <button
          onClick={() => setActiveTab('browse')}
          className={`py-1 px-2.5 rounded-lg cursor-pointer ${activeTab === 'browse' ? 'text-[#0f382c] font-semibold bg-stone-100' : ''}`}
        >
          Browse
        </button>
        <button
          onClick={() => setActiveTab(isLoggedIn ? 'profile' : 'login')}
          className={`py-1 px-2.5 rounded-lg cursor-pointer ${activeTab === 'profile' || activeTab === 'login' ? 'text-[#0f382c] font-semibold bg-stone-100' : ''}`}
        >
          {isLoggedIn ? 'Profile' : 'Login'}
        </button>
        <button
          onClick={() => setActiveTab('store')}
          className={`py-1 px-2.5 rounded-lg cursor-pointer ${activeTab === 'store' ? 'text-[#0f382c] font-semibold bg-stone-100' : ''}`}
        >
          My store
        </button>
        <button
          onClick={() => setActiveTab('messages')}
          className={`py-1 px-2.5 rounded-lg cursor-pointer ${activeTab === 'messages' ? 'text-[#0f382c] font-semibold bg-stone-100' : ''}`}
        >
          Messages
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`py-1 px-2.5 rounded-lg cursor-pointer ${activeTab === 'orders' ? 'text-[#0f382c] font-semibold bg-stone-100' : ''}`}
        >
          Orders
        </button>
      </div>
    </header>
  );
};
