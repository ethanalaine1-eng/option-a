import React from 'react';
import { MapPin, ShieldCheck } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  onOpenSellModal: () => void;
  onOpenAdminModal: () => void;
  onOpenVerificationModal: () => void;
  onOpenReportModal?: () => void;
  onOpenSafetyTipsModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  setActiveTab,
  onOpenSellModal,
  onOpenAdminModal,
  onOpenVerificationModal,
  onOpenReportModal,
  onOpenSafetyTipsModal
}) => {
  return (
    <footer className="border-t border-stone-200/80 bg-[#f7f7f3] pt-16 pb-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-8 pb-12">
          {/* Brand info matching user's screenshot exactly */}
          <div className="md:col-span-6 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#0f382c] flex items-center justify-center text-white font-serif font-bold text-xl shadow-xs">
                S
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-xl sm:text-[1.35rem] font-medium tracking-tight text-[#143d31] leading-tight">
                  Soko Maseno
                </span>
                <span className="text-[10px] tracking-widest uppercase font-semibold text-[#0f382c]/80">
                  MASENO UNIVERSITY
                </span>
              </div>
            </div>

            <p className="text-sm text-stone-600 max-w-md leading-relaxed font-light">
              The student marketplace for Maseno University — Main Campus, Siriba, Odera Akang'o &amp; Kisumu. Textbooks, gadgets, thrift, food and rooms, all within comrade reach.
            </p>

            <div className="space-y-1.5 text-xs text-stone-500 pt-1">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                <span>Private Bag, Maseno · along Kisumu–Busia Rd · On the Equator</span>
              </div>
              <div className="flex items-start gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                <span>Verified seller profiles · Prices in KSh</span>
              </div>
            </div>
          </div>

          {/* MARKETPLACE links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold text-stone-400 tracking-wider uppercase">
              MARKETPLACE
            </h4>
            <ul className="space-y-2.5 text-sm text-stone-700">
              <li>
                <button
                  onClick={() => { setActiveTab('browse'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Browse listings
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenSellModal}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Sell an item
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('orders'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Track orders
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('messages'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Messages
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('store'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  My store
                </button>
              </li>
            </ul>
          </div>

          {/* TRUST & SAFETY links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold text-stone-400 tracking-wider uppercase">
              TRUST &amp; SAFETY
            </h4>
            <ul className="space-y-2.5 text-sm text-stone-700">
              <li>
                <button
                  onClick={onOpenVerificationModal}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Get verified badge
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenAdminModal}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Admin portal
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (onOpenReportModal) {
                      onOpenReportModal();
                    } else {
                      alert("Opening Report Desk...");
                    }
                  }}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Report a problem
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (onOpenSafetyTipsModal) {
                      onOpenSafetyTipsModal();
                    } else {
                      alert("Opening Safety tips...");
                    }
                  }}
                  className="hover:text-stone-900 transition cursor-pointer text-left"
                >
                  Safety tips
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright matching screenshot */}
        <div className="border-t border-stone-200/70 pt-8 text-center text-xs text-stone-500">
          © 2026 Soko Maseno · Made for Maseno University comrades
        </div>
      </div>
    </footer>
  );
};
