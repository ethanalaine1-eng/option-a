import React, { useState } from 'react';
import { 
  Store, 
  Lock, 
  Mail, 
  Phone, 
  User, 
  ArrowRight, 
  Eye, 
  EyeOff 
} from 'lucide-react';
import { UserProfile } from '../types';

interface LoginPageProps {
  onLoginSuccess: (user: UserProfile) => void;
  onRegisterSuccess: (newUser: UserProfile) => void;
  existingUsers: UserProfile[];
  redirectReason?: string | null;
  onCancel?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  onRegisterSuccess,
  existingUsers,
  redirectReason,
  onCancel
}) => {
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('ethan.alaine@student.maseno.ac.ke');
  const [loginPassword, setLoginPassword] = useState('comrade123');

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regCampus, setRegCampus] = useState('Main Campus — Maseno Township');
  const [regStudentId, setRegStudentId] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regMeetup, setRegMeetup] = useState('Main Gate, Maseno');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim()) {
      alert('Please enter your Maseno student email or phone number.');
      return;
    }

    // Match existing user by email or phone, or construct a session
    const matched = existingUsers.find(
      u => u.email.toLowerCase() === loginIdentifier.trim().toLowerCase() ||
           u.phone.replace(/\s+/g, '') === loginIdentifier.replace(/\s+/g, '')
    );

    if (matched) {
      onLoginSuccess(matched);
    } else {
      // Auto-create/fallback comrade profile if new username
      const fallbackUser: UserProfile = {
        id: 'user-' + Date.now(),
        name: loginIdentifier.includes('@') 
          ? loginIdentifier.split('@')[0].replace('.', ' ').replace(/(^\w|\s\w)/g, m => m.toUpperCase())
          : 'Maseno Comrade',
        university: 'Maseno University',
        campus: 'Main Campus — Maseno Township',
        phone: loginIdentifier.includes('@') ? '0712 345 678' : loginIdentifier,
        email: loginIdentifier.includes('@') ? loginIdentifier : `${loginIdentifier}@student.maseno.ac.ke`,
        defaultMeetup: 'Main Gate, Maseno',
        bio: 'Maseno University student trading on campus.',
        isVerified: false,
        memberSince: 'Today',
        totalDeals: 0,
        rating: 5.0,
        listingsCount: 0,
        savedCount: 0
      };
      onLoginSuccess(fallbackUser);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regFullName.trim() || !regPhone.trim()) {
      alert('Please fill in your name and phone number.');
      return;
    }

    const newUser: UserProfile = {
      id: 'user-' + Date.now(),
      name: regFullName.trim(),
      regNumber: regStudentId.trim() || undefined,
      university: 'Maseno University',
      campus: regCampus,
      email: regEmail.trim() || `${regFullName.toLowerCase().replace(/\s+/g, '.')}@student.maseno.ac.ke`,
      phone: regPhone.trim(),
      defaultMeetup: regMeetup.trim() || 'Main Gate, Maseno',
      bio: 'Maseno University comrade ready to buy and sell.',
      isVerified: false,
      verificationRequested: false,
      memberSince: 'Today',
      totalDeals: 0,
      rating: 5.0,
      listingsCount: 0,
      savedCount: 0
    };

    onRegisterSuccess(newUser);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-10 px-4 sm:px-6">
      <div className="w-full max-w-md bg-white rounded-[2.5rem] border border-stone-200/90 shadow-xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Top Visual Header */}
        <div className="bg-gradient-to-br from-[#0d3b2e] via-[#104335] to-[#174d3e] p-8 text-white text-center relative overflow-hidden">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Store className="w-6 h-6 text-white" />
          </div>
          
          <h2 className="font-serif text-3xl font-normal text-white">
            Soko Maseno
          </h2>
          <p className="text-xs text-emerald-100/80 font-light mt-1">
            Maseno University Student Marketplace
          </p>

          {redirectReason && (
            <div className="mt-4 p-3 bg-white/15 backdrop-blur-md rounded-2xl border border-white/25 text-xs text-emerald-50 leading-snug">
              🔒 <strong>Sign in Required:</strong> {redirectReason}
            </div>
          )}
        </div>

        {/* Tab switch between Sign In and Sign Up */}
        <div className="flex border-b border-stone-100 bg-stone-50/50">
          <button
            type="button"
            onClick={() => setIsRegisterMode(false)}
            className={`flex-1 py-3.5 text-xs sm:text-sm font-semibold transition cursor-pointer border-b-2 ${
              !isRegisterMode
                ? 'border-[#0f382c] text-[#0f382c] bg-white'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => setIsRegisterMode(true)}
            className={`flex-1 py-3.5 text-xs sm:text-sm font-semibold transition cursor-pointer border-b-2 ${
              isRegisterMode
                ? 'border-[#0f382c] text-[#0f382c] bg-white'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Create Comrade Account
          </button>
        </div>

        {/* Forms Container */}
        <div className="p-6 sm:p-8 space-y-6">
          {!isRegisterMode ? (
            /* SIGN IN FORM */
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1.5">
                  Maseno Student Email or Phone Number *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="e.g. ethan.alaine@student.maseno.ac.ke or 0712..."
                    className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-medium text-stone-700">
                    Password *
                  </label>
                  <button
                    type="button"
                    onClick={() => alert("Password reset link sent to your student email inbox.")}
                    className="text-[11px] text-[#0f382c] hover:underline cursor-pointer"
                  >
                    Forgot?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Quick Preset Comrade Login Buttons */}
              <div className="pt-1">
                <span className="text-[11px] text-stone-400 block mb-1.5">
                  Quick Sign-In accounts:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {existingUsers.slice(0, 3).map((u) => (
                    <button
                      type="button"
                      key={u.id}
                      onClick={() => {
                        setLoginIdentifier(u.email);
                        setLoginPassword('comrade123');
                      }}
                      className="text-[11px] px-2.5 py-1 bg-stone-100 hover:bg-emerald-50 hover:text-[#0f382c] border border-stone-200 rounded-lg text-stone-600 transition cursor-pointer"
                    >
                      {u.name.split(' ')[0]} ({u.campus.split('—')[0].trim()})
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-sm font-medium shadow-md transition active:scale-95 cursor-pointer"
                >
                  <span>Sign In &amp; Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="text-center pt-2">
                <p className="text-xs text-stone-500">
                  New to Soko Maseno?{' '}
                  <button
                    type="button"
                    onClick={() => setIsRegisterMode(true)}
                    className="text-[#0f382c] font-semibold hover:underline cursor-pointer"
                  >
                    Create account here
                  </button>
                </p>
              </div>
            </form>
          ) : (
            /* CREATE ACCOUNT FORM */
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Stacy Achieng"
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Phone / Contact *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      required
                      placeholder="0712 345 678"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Campus *
                  </label>
                  <select
                    value={regCampus}
                    onChange={(e) => setRegCampus(e.target.value)}
                    className="w-full px-2.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                  >
                    <option value="Main Campus — Maseno Township">Main Campus</option>
                    <option value="Siriba Campus (Main)">Siriba Campus</option>
                    <option value="College Campus">College Campus</option>
                    <option value="Kisumu City Campus (Varsity Plaza)">Kisumu Varsity Plaza</option>
                    <option value="Odera Akang’o Campus">Odera Akang'o</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Maseno Student Registration No. (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. CI/00912/023"
                  value={regStudentId}
                  onChange={(e) => setRegStudentId(e.target.value)}
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Create Password *
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="password"
                    required
                    placeholder="At least 6 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Default Campus Meetup Location
                </label>
                <input
                  type="text"
                  placeholder="e.g. Millennium Library or Main Gate"
                  value={regMeetup}
                  onChange={(e) => setRegMeetup(e.target.value)}
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:border-stone-400"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-sm font-medium shadow-md transition active:scale-95 cursor-pointer"
                >
                  <span>Register &amp; Start Trading</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="text-center pt-1">
                <p className="text-xs text-stone-500">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setIsRegisterMode(false)}
                    className="text-[#0f382c] font-semibold hover:underline cursor-pointer"
                  >
                    Sign in here
                  </button>
                </p>
              </div>
            </form>
          )}

          {onCancel && (
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={onCancel}
                className="text-xs text-stone-400 hover:text-stone-700 underline cursor-pointer"
              >
                Continue browsing without signing in
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
