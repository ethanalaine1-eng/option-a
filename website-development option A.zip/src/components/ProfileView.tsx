import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Save, 
  ShieldCheck, 
  UserPlus, 
  Check
} from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileViewProps {
  currentUser: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onOpenVerificationModal: () => void;
  onOpenAuthModal: () => void;
  usersList: UserProfile[];
  onSwitchUser: (userId: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  onUpdateProfile,
  onOpenVerificationModal,
  onOpenAuthModal,
  usersList,
  onSwitchUser
}) => {
  const [name, setName] = useState(currentUser.name);
  const [campus, setCampus] = useState(currentUser.campus);
  const [phone, setPhone] = useState(currentUser.phone);
  const [defaultMeetup, setDefaultMeetup] = useState(currentUser.defaultMeetup);
  const [bio, setBio] = useState(currentUser.bio);
  const [email, setEmail] = useState(currentUser.email);
  const [isSaved, setIsSaved] = useState(false);

  // Sync if currentUser changes (e.g. account switched)
  React.useEffect(() => {
    setName(currentUser.name);
    setCampus(currentUser.campus);
    setPhone(currentUser.phone);
    setDefaultMeetup(currentUser.defaultMeetup);
    setBio(currentUser.bio);
    setEmail(currentUser.email);
  }, [currentUser]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...currentUser,
      name: name.trim() || 'Comrade',
      campus: campus.trim() || 'Main Campus — Maseno Township',
      phone: phone.trim() || '0700 000 000',
      defaultMeetup: defaultMeetup.trim() || 'Main Gate, Maseno',
      bio: bio.trim(),
      email: email.trim()
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const getInitials = (n: string) => {
    return n
      .split(' ')
      .map(part => part[0])
      .join('')
      .slice(0, 2)
      .toUpperCase() || 'U';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pt-4 pb-20">
      {/* Top Header matching screenshot */}
      <div className="space-y-1">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="font-serif text-4xl sm:text-5xl text-[#143d31] font-normal tracking-tight">
            My profile
          </h1>
          
          {/* Quick Account Switcher / Create Account Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenAuthModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-stone-200 bg-white hover:bg-stone-50 text-xs text-stone-700 font-medium transition cursor-pointer shadow-2xs"
            >
              <UserPlus className="w-3.5 h-3.5 text-[#0f382c]" />
              <span>Create / Switch Account</span>
            </button>
          </div>
        </div>
        <p className="text-stone-500 text-sm font-light">
          Verified comrades sell faster — keep your profile complete.
        </p>
      </div>

      {/* Main Profile Card matching screenshot */}
      <div className="bg-white rounded-[2rem] border border-stone-200/80 p-6 sm:p-8 space-y-8 shadow-xs">
        {/* Top Identity Block */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-stone-100">
          <div className="flex items-center gap-4 sm:gap-5">
            {/* Square Rounded Avatar matching Screenshot */}
            <div className="w-20 h-20 rounded-2xl bg-[#0f382c] text-white flex items-center justify-center font-serif text-2xl font-bold shrink-0 shadow-sm">
              {getInitials(name)}
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-2xl sm:text-3xl text-stone-900 font-normal">
                  {name}
                </h2>
                {currentUser.isVerified && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 stroke-[2.2]" />
                )}
              </div>
              <p className="text-xs text-stone-500">
                Maseno University · {currentUser.rating?.toFixed(1) || '5.0'}★ · {currentUser.listingsCount || 0} listings · {currentUser.savedCount || 0} saved
              </p>
            </div>
          </div>

          {/* Verification Badge pill matching screenshot */}
          <div>
            {currentUser.isVerified ? (
              <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
                Verified · Student ID checked
              </span>
            ) : currentUser.verificationRequested ? (
              <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200">
                Verification Pending Review
              </span>
            ) : (
              <button
                type="button"
                onClick={onOpenVerificationModal}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-medium bg-stone-100 hover:bg-emerald-50 text-stone-700 hover:text-emerald-800 border border-stone-200 hover:border-emerald-300 transition cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Request Verification Badge</span>
              </button>
            )}
          </div>
        </div>

        {/* Profile Edit Form */}
        <form onSubmit={handleSave} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-medium text-stone-800 mb-1.5">
                Full name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ethan Alaine"
                className="w-full px-4 py-3 bg-stone-50/70 border border-stone-200/90 rounded-2xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white transition"
              />
            </div>

            {/* Campus */}
            <div>
              <label className="block text-xs font-medium text-stone-800 mb-1.5">
                Campus
              </label>
              <input
                type="text"
                required
                value={campus}
                onChange={(e) => setCampus(e.target.value)}
                placeholder="e.g. Main Campus — Maseno Township"
                className="w-full px-4 py-3 bg-stone-50/70 border border-stone-200/90 rounded-2xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white transition"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-medium text-stone-800 mb-1.5">
                Phone
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. 0712 345 678"
                className="w-full px-4 py-3 bg-stone-50/70 border border-stone-200/90 rounded-2xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white transition"
              />
            </div>

            {/* Default meet-up spot */}
            <div>
              <label className="block text-xs font-medium text-stone-800 mb-1.5">
                Default meet-up spot
              </label>
              <input
                type="text"
                required
                value={defaultMeetup}
                onChange={(e) => setDefaultMeetup(e.target.value)}
                placeholder="e.g. Main Gate, Maseno or Millennium Library"
                className="w-full px-4 py-3 bg-stone-50/70 border border-stone-200/90 rounded-2xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white transition"
              />
            </div>
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-xs font-medium text-stone-800 mb-1.5">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. comrade@student.maseno.ac.ke"
              className="w-full px-4 py-3 bg-stone-50/70 border border-stone-200/90 rounded-2xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white transition"
            />
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-medium text-stone-800 mb-1.5">
              Bio
            </label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Describe what you study or what you trade..."
              className="w-full px-4 py-3 bg-stone-50/70 border border-stone-200/90 rounded-2xl text-sm text-stone-900 focus:outline-none focus:border-stone-400 focus:bg-white transition resize-none leading-relaxed"
            />
          </div>

          {/* Save Action Bar */}
          <div className="pt-2 flex items-center justify-between flex-wrap gap-4">
            <span className="text-xs text-stone-400">
              Changes reflect immediately on all your listings and chats.
            </span>
            <div className="flex items-center gap-3">
              {isSaved && (
                <span className="inline-flex items-center gap-1.5 text-xs text-emerald-700 font-medium animate-in fade-in">
                  <Check className="w-4 h-4" />
                  Saved successfully!
                </span>
              )}
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-7 py-3 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-xs sm:text-sm font-medium shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </button>
            </div>
          </div>
        </form>

        {/* Existing Accounts Switcher */}
        {usersList.length > 1 && (
          <div className="pt-6 border-t border-stone-100 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-400 block">
              Comrade Profiles On This Device ({usersList.length})
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {usersList.map((u) => (
                <div
                  key={u.id}
                  onClick={() => onSwitchUser(u.id)}
                  className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                    u.id === currentUser.id
                      ? 'border-[#0f382c] bg-emerald-50/40 shadow-xs'
                      : 'border-stone-200 hover:border-stone-300 bg-stone-50/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <div className="w-8 h-8 rounded-xl bg-[#0f382c] text-white flex items-center justify-center font-bold text-xs shrink-0">
                      {getInitials(u.name)}
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-medium text-stone-900 truncate">
                        {u.name}
                      </div>
                      <div className="text-[11px] text-stone-400 truncate">
                        {u.campus.split('—')[0]}
                      </div>
                    </div>
                  </div>
                  {u.id === currentUser.id && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-semibold">
                      Current
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
