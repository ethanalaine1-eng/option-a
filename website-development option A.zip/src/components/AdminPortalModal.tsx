import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, UserCheck, AlertTriangle, School } from 'lucide-react';

interface AdminPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  isOpen,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'verifications' | 'safety' | 'analytics'>('verifications');

  const [pendingVerifications, setPendingVerifications] = useState([
    {
      id: 'v1',
      name: 'Faith Chebet',
      studentId: 'ED/00234/022',
      department: 'School of Education (Siriba Campus)',
      date: 'Today, 09:12',
      status: 'pending'
    },
    {
      id: 'v2',
      name: 'Dennis Kimani',
      studentId: 'CI/00912/023',
      department: 'School of Computing & Informatics (College Campus)',
      date: 'Yesterday, 14:30',
      status: 'pending'
    }
  ]);

  const handleApprove = (id: string) => {
    setPendingVerifications(prev => prev.filter(v => v.id !== id));
    alert('Maseno student vendor identity verified successfully! Green badge granted.');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#0f382c] flex items-center justify-center text-white">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg text-stone-900 font-medium">
                Maseno University Admin Portal
              </h2>
              <p className="text-[11px] text-stone-400">Campus Student Verification &amp; Trust Oversight</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 border-b border-stone-100 flex items-center gap-6 text-xs font-medium text-stone-500 pt-2">
          <button
            onClick={() => setActiveTab('verifications')}
            className={`pb-3 relative transition cursor-pointer ${activeTab === 'verifications' ? 'text-[#0f382c] font-semibold' : 'hover:text-stone-800'}`}
          >
            Student ID Verifications ({pendingVerifications.length})
            {activeTab === 'verifications' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0f382c]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('safety')}
            className={`pb-3 relative transition cursor-pointer ${activeTab === 'safety' ? 'text-[#0f382c] font-semibold' : 'hover:text-stone-800'}`}
          >
            Maseno Campus Trust &amp; Safety
            {activeTab === 'safety' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0f382c]" />
            )}
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[70vh] overflow-y-auto space-y-4">
          {activeTab === 'verifications' ? (
            <div className="space-y-3">
              <div className="text-xs text-stone-500">
                Pending Maseno University student ID submissions requesting the verified vendor checkmark:
              </div>

              {pendingVerifications.length === 0 ? (
                <div className="p-8 text-center text-stone-400 text-xs border border-dashed border-stone-200 rounded-2xl">
                  All Maseno student verifications reviewed! No pending submissions.
                </div>
              ) : (
                pendingVerifications.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-stone-900">{item.name}</span>
                        <span className="text-[11px] px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md">Pending</span>
                      </div>
                      <div className="text-xs text-stone-600 mt-1">
                        Reg: <span className="font-mono font-medium">{item.studentId}</span> · {item.department}
                      </div>
                      <span className="text-[10px] text-stone-400">Submitted: {item.date}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleApprove(item.id)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#0f382c] hover:bg-[#154637] text-white rounded-full text-xs font-medium transition shadow-2xs cursor-pointer"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Verify Student</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            <div className="space-y-4 text-xs text-stone-600">
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-emerald-950 text-sm">Maseno University Campus Trust: 99.6%</h4>
                  <p className="mt-0.5 text-stone-600">
                    Active moderation for Siriba, College, Kisumu and Odera Akang'o campuses. Safe trading spots designated at Millennium Library and Siriba Mess.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                <h4 className="font-semibold text-stone-800 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>Prohibited Maseno Trade Items</span>
                </h4>
                <p>
                  Unauthorized exam papers/leakages, non-prescribed pharmaceuticals, unauthorized commercial flyers, and hazardous appliances banned in student halls.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                <h4 className="font-semibold text-stone-800 flex items-center gap-1.5">
                  <School className="w-4 h-4 text-[#0f382c]" />
                  <span>Hostel Guidelines</span>
                </h4>
                <p>
                  Hostel room sublets must comply with Maseno Dean of Students housing rules and off-campus private hostel agreements (Sunrise, Golden, Equator View).
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-3 border-t border-stone-100 bg-stone-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-stone-600 hover:text-stone-900 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
