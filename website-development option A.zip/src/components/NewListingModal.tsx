import React, { useState } from 'react';
import { X, School, MapPin } from 'lucide-react';
import { Category, CategoryId, ItemCondition, Listing } from '../types';

interface NewListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  onSubmitListing: (listing: Listing) => void;
}

const PRESET_IMAGES: { label: string; url: string; cat: CategoryId }[] = [
  {
    label: 'Textbook / Study Notes',
    url: 'https://images.pexels.com/photos/34889792/pexels-photo-34889792.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    cat: 'textbooks'
  },
  {
    label: 'Laptop / Gadget',
    url: 'https://images.pexels.com/photos/4533076/pexels-photo-4533076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    cat: 'electronics'
  },
  {
    label: 'Headphones / Audio',
    url: 'https://images.pexels.com/photos/18311089/pexels-photo-18311089.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    cat: 'electronics'
  },
  {
    label: 'Campus Thrift Clothing',
    url: 'https://images.pexels.com/photos/5965726/pexels-photo-5965726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    cat: 'fashion'
  },
  {
    label: 'Desk Supplies / Pens',
    url: 'https://images.pexels.com/photos/37793421/pexels-photo-37793421.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    cat: 'services'
  },
  {
    label: 'Hostel Room / Space',
    url: 'https://images.pexels.com/photos/40144605/pexels-photo-40144605.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    cat: 'hostels'
  }
];

const MASENO_MEETUP_POINTS = [
  'Siriba Campus - Millennium Library Steps',
  'Siriba Mess / Student Center',
  'Equator Monument / Gate A',
  'College Campus - Hall 4 Breezeway',
  'College Campus - Education Complex',
  'Sunrise Hostels - Gate B Maseno',
  'Varsity Plaza - Kisumu City Campus'
];

export const NewListingModal: React.FC<NewListingModalProps> = ({
  isOpen,
  onClose,
  categories,
  onSubmitListing
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<CategoryId>('textbooks');
  const [price, setPrice] = useState('');
  const [condition, setCondition] = useState<ItemCondition>('Like New');
  const [campus, setCampus] = useState('Siriba Campus (Main)');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState(MASENO_MEETUP_POINTS[0]);
  const [imageUrl, setImageUrl] = useState(PRESET_IMAGES[0].url);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !price) {
      alert('Please enter a title and price.');
      return;
    }

    const newListing: Listing = {
      id: 'item-' + Date.now(),
      title: title.trim(),
      price: parseFloat(price) || 0,
      category,
      condition,
      description: description.trim() || 'No description provided.',
      location: location.trim() || 'Siriba Campus - Millennium Library',
      image: imageUrl,
      sellerId: 'ethan-alaine',
      sellerName: 'Ethan Alaine',
      sellerRating: 5.0,
      sellerVerified: true,
      campus,
      createdAt: 'Just now',
      status: 'active',
      views: 1,
      inquiries: 0
    };

    onSubmitListing(newListing);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-[2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#0f382c] flex items-center justify-center text-white text-xs font-bold">
              +
            </div>
            <div>
              <h2 className="font-serif text-xl text-stone-900 font-medium">
                Create new listing
              </h2>
              <p className="text-[11px] text-stone-400">Maseno University student trade · Free to list</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Title */}
          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Item Title *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. MAT 101 Notes, HP Laptop Charger, or Equator Fleece"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-400 focus:bg-white"
            />
          </div>

          {/* Category & Condition Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => {
                  const newCat = e.target.value as CategoryId;
                  setCategory(newCat);
                  const matchingPreset = PRESET_IMAGES.find(p => p.cat === newCat);
                  if (matchingPreset) setImageUrl(matchingPreset.url);
                }}
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-800 focus:outline-none focus:border-stone-400"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Condition *
              </label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as ItemCondition)}
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-800 focus:outline-none focus:border-stone-400"
              >
                <option value="Brand New">Brand New</option>
                <option value="Like New">Like New</option>
                <option value="Good">Good</option>
                <option value="Fair">Fair</option>
              </select>
            </div>
          </div>

          {/* Maseno Campus & Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Maseno Campus *
              </label>
              <div className="relative">
                <School className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  value={campus}
                  onChange={(e) => setCampus(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-800 focus:outline-none focus:border-stone-400"
                >
                  <option value="Siriba Campus (Main)">Siriba Campus (Main)</option>
                  <option value="College Campus">College Campus</option>
                  <option value="Kisumu City Campus (Varsity Plaza)">Kisumu City Campus (Varsity Plaza)</option>
                  <option value="Odera Akang’o Campus">Odera Akang’o Campus</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Price (Kenyan Shillings - KSh) *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-stone-400">
                  KSh
                </span>
                <input
                  type="number"
                  required
                  min="1"
                  placeholder="1500"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full pl-12 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-400 focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Campus Meetup Location with Maseno points */}
          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Campus Meetup Location *
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-stone-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="e.g. Millennium Library, Siriba Mess, Sunrise Gate B"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-400 focus:bg-white"
              />
            </div>
            <div className="flex flex-wrap gap-1 mt-1.5">
              <span className="text-[10px] text-stone-400">Quick suggestions:</span>
              {MASENO_MEETUP_POINTS.slice(0, 3).map((pt) => (
                <button
                  type="button"
                  key={pt}
                  onClick={() => setLocation(pt)}
                  className="text-[10px] bg-stone-100 hover:bg-stone-200 text-stone-600 px-2 py-0.5 rounded-md cursor-pointer"
                >
                  {pt.split('-')[0].trim()}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Description
            </label>
            <textarea
              rows={3}
              placeholder="State condition, reason for selling, whether you can deliver to Siriba or College hostels..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-400 focus:bg-white"
            />
          </div>

          {/* Photo Selection / Presets */}
          <div>
            <label className="block text-xs font-medium text-stone-700 mb-2">
              Item Photo (Select preset or enter URL)
            </label>
            
            <div className="grid grid-cols-3 gap-2 mb-3">
              {PRESET_IMAGES.map((preset, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => setImageUrl(preset.url)}
                  className={`relative rounded-xl overflow-hidden aspect-video border-2 transition text-left group cursor-pointer ${
                    imageUrl === preset.url ? 'border-[#0f382c] ring-2 ring-[#0f382c]/20' : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-end p-1 text-[9px] text-white font-medium leading-tight">
                    {preset.label}
                  </div>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <input
                type="url"
                placeholder="Or paste external image URL..."
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-700 focus:outline-none focus:border-stone-400"
              />
            </div>
          </div>

          {/* Submit Actions */}
          <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-full border border-stone-200 text-stone-700 hover:bg-stone-50 text-xs sm:text-sm font-medium transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-full bg-[#0f382c] hover:bg-[#154637] text-white text-xs sm:text-sm font-medium shadow-xs transition active:scale-95 cursor-pointer"
            >
              Publish to Maseno Hub
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
