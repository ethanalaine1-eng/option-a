import React from 'react';
import { X, ShieldCheck, MapPin, Eye, CheckCircle2, PhoneCall } from 'lucide-react';

interface SafetyTipsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReportModal: () => void;
}

export const SafetyTipsModal: React.FC<SafetyTipsModalProps> = ({
  isOpen,
  onClose,
  onOpenReportModal
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-[2.2rem] shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 my-8">
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-emerald-50/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#0f382c] text-white flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg text-stone-900 font-medium">
                Maseno Comrade Safety Tips
              </h2>
              <p className="text-[11px] text-stone-500">Smart guidelines for secure campus trading</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs sm:text-sm text-stone-700">
          <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 space-y-1">
            <div className="font-semibold text-emerald-950 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>1. Always Trade at Designated Maseno Meetup Points</span>
            </div>
            <p className="text-stone-600 leading-relaxed text-xs">
              Meet in daylight at public student landmarks: <strong>Millennium Library steps</strong>, <strong>Siriba Mess / Student Centre</strong>, <strong>Equator Monument</strong>, or <strong>College Campus common room</strong>. Never meet in secluded off-campus alleys after 7:00 PM.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-1">
            <div className="font-semibold text-amber-950 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-amber-700" />
              <span>2. Inspect Before Paying (Never Send Advance M-Pesa)</span>
            </div>
            <p className="text-stone-600 leading-relaxed text-xs">
              Genuine Maseno comrades will never ask for advance fuel, fare, or booking fee before you see the item. Test laptop chargers, inspect textbook pages, and verify phone IMEI numbers in person.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
            <div className="font-semibold text-stone-900 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#0f382c]" />
              <span>3. Prefer Verified Comrade Profiles</span>
            </div>
            <p className="text-stone-600 leading-relaxed text-xs">
              Sellers with the green verified badge have confirmed their student identity with their Maseno University student registration number.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
            <div className="font-semibold text-stone-900 flex items-center gap-1.5">
              <PhoneCall className="w-4 h-4 text-[#0f382c]" />
              <span>4. Verify Bedsitters and Sublets with Caretakers</span>
            </div>
            <p className="text-stone-600 leading-relaxed text-xs">
              When booking bedsitters around Sunrise, Golden, or Gate B, always verify with the physical hostel caretaker or landlord before paying rent deposits.
            </p>
          </div>
        </div>

        <div className="px-6 py-3 border-t border-stone-100 bg-stone-50 flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onOpenReportModal();
            }}
            className="text-xs text-rose-700 hover:text-rose-900 font-medium underline cursor-pointer"
          >
            Report suspicious seller / item →
          </button>
          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-full bg-[#0f382c] hover:bg-[#144838] text-white text-xs font-medium cursor-pointer"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
