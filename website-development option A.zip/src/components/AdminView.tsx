import React, { useState } from 'react';
import { Category, Listing, OrderItem, Conversation } from '../types';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  initials: string;
  isVerified: boolean;
  role: 'user' | 'admin';
  status: 'active' | 'suspended';
  documentUrl?: string;
}

interface AdminViewProps {
  listings: Listing[];
  orders: OrderItem[];
  categories: Category[];
  conversations: Conversation[];
  onDeleteListing?: (id: string) => void;
  onUpdateCategoryCount?: (catId: string, count: number) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  listings,
  orders,
  categories,
  conversations,
  onDeleteListing
}) => {
  // Stat counters
  const [activeTab, setActiveTab] = useState<'Users' | 'Listings' | 'Categories' | 'Appeals' | 'Orders' | 'Conversations'>('Users');

  // Users state initialized matching screenshot: 4 users
  const [users, setUsers] = useState<AdminUser[]>([
    {
      id: 'u1',
      name: 'Caleb Mbugua',
      email: 'calebmmbugua@gmail.com',
      initials: 'CM',
      isVerified: false,
      role: 'user',
      status: 'active'
    },
    {
      id: 'u2',
      name: 'Rael Anyango',
      email: 'raelaopiyo24@gmail.com',
      initials: 'RA',
      isVerified: false,
      role: 'user',
      status: 'active'
    },
    {
      id: 'u3',
      name: 'Mash Mellow',
      email: 'mashmellow2024@gmail.com',
      initials: 'MM',
      isVerified: true,
      role: 'user',
      status: 'active',
      documentUrl: 'Student_ID_Maseno_CI00842.pdf'
    },
    {
      id: 'u4',
      name: 'Ethan Alaine',
      email: 'ethan.alaine@student.maseno.ac.ke',
      initials: 'EA',
      isVerified: false,
      role: 'admin',
      status: 'active',
      documentUrl: 'Maseno_ID_CI00842022.pdf'
    }
  ]);

  // Appeals state
  const [appeals, setAppeals] = useState([
    {
      id: 'ap-1',
      userName: 'Rael Anyango',
      userEmail: 'raelaopiyo24@gmail.com',
      reason: 'Account flagged for rapid listing inquiry tests. Requesting verification confirmation.',
      date: 'Yesterday, 18:22',
      status: 'Pending'
    }
  ]);

  // Actions on users
  const handleToggleVerify = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        return { ...u, isVerified: !u.isVerified };
      }
      return u;
    }));
  };

  const handleToggleSuspend = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const nextStatus = u.status === 'active' ? 'suspended' : 'active';
        return { ...u, status: nextStatus };
      }
      return u;
    }));
  };

  const handleToggleAdmin = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        return { ...u, role: u.role === 'admin' ? 'user' : 'admin' };
      }
      return u;
    }));
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm("Are you sure you want to delete this user account?")) {
      setUsers(prev => prev.filter(u => u.id !== userId));
    }
  };

  const verificationRequestsCount = users.filter(u => !u.isVerified && u.documentUrl).length;

  return (
    <div className="space-y-8 pt-4 pb-16">
      {/* Title matching screenshot */}
      <div>
        <h1 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
          Admin
        </h1>
      </div>

      {/* 4 Stat Cards matching screenshot exactly */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* USERS: 4 */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
            USERS
          </span>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {users.length}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Registered accounts
          </div>
        </div>

        {/* ACTIVE LISTINGS: 0 */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
            ACTIVE LISTINGS
          </span>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {listings.length}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Live on marketplace
          </div>
        </div>

        {/* ORDERS */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
            ORDERS
          </span>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {orders.length}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Total transactions
          </div>
        </div>

        {/* VERIFICATION REQUESTS: 0 */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
            VERIFICATION REQUESTS
          </span>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {verificationRequestsCount}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Pending student ID review
          </div>
        </div>
      </div>

      {/* Pill Filter Tabs matching Screenshot */}
      <div className="flex flex-wrap items-center gap-2 pt-2">
        {(['Users', 'Listings', 'Categories', 'Appeals', 'Orders', 'Conversations'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2 rounded-full text-xs sm:text-sm font-medium transition cursor-pointer ${
              activeTab === tab
                ? 'bg-[#0f382c] text-white shadow-2xs'
                : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* TAB CONTENT */}

      {/* 1. USERS TAB: Matches screenshot exactly */}
      {activeTab === 'Users' && (
        <div className="bg-white rounded-3xl border border-stone-200/80 shadow-2xs overflow-hidden divide-y divide-stone-100">
          {users.map((user) => (
            <div
              key={user.id}
              className="p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-stone-50/50 transition"
            >
              {/* User Avatar + Name + Email */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-700 flex items-center justify-center font-semibold text-sm shrink-0 border border-stone-200/60">
                  {user.initials}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium text-stone-900 text-sm sm:text-base">
                      {user.name}
                    </h3>
                    {user.role === 'admin' && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                        Admin
                      </span>
                    )}
                    {user.status === 'suspended' && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-semibold">
                        Suspended
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-500 mt-0.5 font-light">
                    {user.email}
                  </p>
                </div>
              </div>

              {/* Actions Right Side matching screenshot buttons */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
                {/* Status Indicator text (Unverified / Verified) */}
                <span className={`px-2 py-1 text-xs font-medium ${
                  user.isVerified ? 'text-emerald-700' : 'text-stone-500'
                }`}>
                  {user.isVerified ? 'Verified' : 'Unverified'}
                </span>

                {/* Document link if uploaded */}
                {user.documentUrl && (
                  <button
                    onClick={() => alert(`Document Preview: ${user.documentUrl}\nStudent ID verified for Maseno University!`)}
                    className="text-stone-700 hover:text-stone-900 underline font-medium px-2 py-1 cursor-pointer"
                  >
                    Document
                  </button>
                )}

                {/* Verify / Unverify Pill Button */}
                <button
                  onClick={() => handleToggleVerify(user.id)}
                  className="px-3.5 py-1.5 rounded-full border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 font-medium transition cursor-pointer"
                >
                  {user.isVerified ? 'Unverify' : 'Verify'}
                </button>

                {/* Suspend / Unsuspend Pill Button with red text */}
                <button
                  onClick={() => handleToggleSuspend(user.id)}
                  className={`px-3.5 py-1.5 rounded-full border border-rose-200 bg-white hover:bg-rose-50 font-medium transition cursor-pointer ${
                    user.status === 'suspended' ? 'text-amber-700 border-amber-200' : 'text-rose-700'
                  }`}
                >
                  {user.status === 'suspended' ? 'Unsuspend' : 'Suspend'}
                </button>

                {/* Make admin / Revoke admin Pill Button */}
                <button
                  onClick={() => handleToggleAdmin(user.id)}
                  className="px-3.5 py-1.5 rounded-full border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 font-medium transition cursor-pointer"
                >
                  {user.role === 'admin' ? 'Revoke admin' : 'Make admin'}
                </button>

                {/* Delete account Solid Red Pill Button */}
                <button
                  onClick={() => handleDeleteUser(user.id)}
                  className="px-4 py-1.5 rounded-full bg-[#c52b2b] hover:bg-[#a92222] text-white font-medium transition active:scale-95 shadow-2xs cursor-pointer"
                >
                  Delete account
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 2. LISTINGS TAB */}
      {activeTab === 'Listings' && (
        <div className="bg-white rounded-3xl border border-stone-200/80 p-8 shadow-2xs">
          <div className="flex items-center justify-between pb-4 border-b border-stone-100 mb-6">
            <div>
              <h3 className="font-serif text-xl text-stone-900">Marketplace Listings</h3>
              <p className="text-xs text-stone-400">Total active listings: {listings.length}</p>
            </div>
          </div>

          {listings.length === 0 ? (
            <div className="py-12 text-center text-stone-400 text-sm">
              No listings currently live in the system.
            </div>
          ) : (
            <div className="divide-y divide-stone-100">
              {listings.map((item) => (
                <div key={item.id} className="py-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img src={item.image} alt={item.title} className="w-12 h-12 rounded-xl object-cover" />
                    <div>
                      <h4 className="font-medium text-sm text-stone-900">{item.title}</h4>
                      <p className="text-xs text-stone-500">KSh {item.price.toLocaleString()} · Seller: {item.sellerName} ({item.campus})</p>
                    </div>
                  </div>
                  {onDeleteListing && (
                    <button
                      onClick={() => onDeleteListing(item.id)}
                      className="px-3.5 py-1.5 rounded-full border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-medium cursor-pointer"
                    >
                      Remove Listing
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 3. CATEGORIES TAB */}
      {activeTab === 'Categories' && (
        <div className="bg-white rounded-3xl border border-stone-200/80 p-8 shadow-2xs">
          <h3 className="font-serif text-xl text-stone-900 mb-4">Maseno Marketplace Categories</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {categories.map((cat) => (
              <div key={cat.id} className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 flex items-center justify-between">
                <div>
                  <h4 className="font-medium text-sm text-stone-900">{cat.name}</h4>
                  <span className="text-xs text-stone-400">{cat.count} listings live</span>
                </div>
                <span className="text-xs px-2 py-1 bg-emerald-50 text-emerald-800 rounded-md font-semibold">Active</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. APPEALS TAB */}
      {activeTab === 'Appeals' && (
        <div className="bg-white rounded-3xl border border-stone-200/80 p-8 shadow-2xs">
          <h3 className="font-serif text-xl text-stone-900 mb-4">Comrade Account &amp; Listing Appeals</h3>
          {appeals.length === 0 ? (
            <div className="py-8 text-center text-stone-400 text-xs">No pending comrade appeals.</div>
          ) : (
            <div className="space-y-3">
              {appeals.map((app) => (
                <div key={app.id} className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-stone-900">{app.userName}</span>
                      <span className="text-xs text-stone-500">({app.userEmail})</span>
                    </div>
                    <p className="text-xs text-stone-600 mt-1">{app.reason}</p>
                    <span className="text-[10px] text-stone-400">{app.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setAppeals(prev => prev.filter(a => a.id !== app.id));
                        alert('Appeal approved and resolved!');
                      }}
                      className="px-3.5 py-1.5 rounded-full bg-[#0f382c] text-white text-xs font-medium cursor-pointer"
                    >
                      Approve Appeal
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 5. ORDERS TAB */}
      {activeTab === 'Orders' && (
        <div className="bg-white rounded-3xl border border-stone-200/80 p-8 shadow-2xs">
          <h3 className="font-serif text-xl text-stone-900 mb-4">Transactions Log ({orders.length})</h3>
          <div className="divide-y divide-stone-100">
            {orders.map((o) => (
              <div key={o.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div>
                  <span className="font-medium text-stone-900">{o.title}</span> · {o.sellerName} ➔ {o.buyerName}
                  <div className="text-stone-400 text-[11px]">{o.date} · {o.meetupLocation}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-stone-800">KSh {o.totalPrice.toLocaleString()}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[11px] font-medium ${
                    o.status === 'Completed' ? 'bg-emerald-50 text-emerald-800' :
                    o.status === 'Cancelled' ? 'bg-stone-100 text-stone-600' : 'bg-amber-50 text-amber-800'
                  }`}>
                    {o.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. CONVERSATIONS TAB */}
      {activeTab === 'Conversations' && (
        <div className="bg-white rounded-3xl border border-stone-200/80 p-8 shadow-2xs">
          <h3 className="font-serif text-xl text-stone-900 mb-4">System Message Logs ({conversations.length})</h3>
          <div className="divide-y divide-stone-100">
            {conversations.map((c) => (
              <div key={c.id} className="py-3.5 flex items-center justify-between gap-4 text-xs">
                <div>
                  <span className="font-semibold text-stone-900">{c.participantName}</span>
                  <span className="text-stone-400 ml-2">Regarding: {c.itemTitle}</span>
                  <p className="text-stone-600 text-[11px] mt-0.5 line-clamp-1">{c.lastMessage}</p>
                </div>
                <span className="text-stone-400 shrink-0">{c.lastMessageTime}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
