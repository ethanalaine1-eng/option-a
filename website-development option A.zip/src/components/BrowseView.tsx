import React, { useState, useMemo } from 'react';
import { 
  Search, 
  ChevronDown, 
  BookOpen, 
  Laptop, 
  Shirt, 
  Utensils, 
  Bed, 
  Sparkles, 
  Bike, 
  Layers, 
  MapPin, 
  CheckCircle2, 
  SlidersHorizontal, 
  RotateCcw, 
  Plus,
  School
} from 'lucide-react';
import { Category, Listing, CategoryId } from '../types';

interface BrowseViewProps {
  categories: Category[];
  listings: Listing[];
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onSelectItem: (item: Listing) => void;
  onOpenSellModal: () => void;
}

const MASENO_CAMPUSES = [
  'All Campuses',
  'Siriba Campus (Main)',
  'College Campus',
  'Kisumu City Campus (Varsity Plaza)',
  'Odera Akang’o Campus'
];

export const BrowseView: React.FC<BrowseViewProps> = ({
  categories,
  listings,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  onSelectItem,
  onOpenSellModal
}) => {
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [conditionFilter, setConditionFilter] = useState<string>('all');
  const [campusFilter, setCampusFilter] = useState<string>('All Campuses');
  const [sortBy, setSortBy] = useState<string>('newest');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const getCategoryIcon = (id: CategoryId | 'all') => {
    switch (id) {
      case 'textbooks':
        return <BookOpen className="w-4 h-4 text-stone-600" />;
      case 'electronics':
        return <Laptop className="w-4 h-4 text-stone-600" />;
      case 'fashion':
        return <Shirt className="w-4 h-4 text-stone-600" />;
      case 'food':
        return <Utensils className="w-4 h-4 text-stone-600" />;
      case 'hostels':
        return <Bed className="w-4 h-4 text-stone-600" />;
      case 'services':
        return <Sparkles className="w-4 h-4 text-stone-600" />;
      case 'transport':
        return <Bike className="w-4 h-4 text-stone-600" />;
      default:
        return <Layers className="w-4 h-4 text-stone-600" />;
    }
  };

  const resetFilters = () => {
    setSelectedCategory('all');
    setMinPrice('');
    setMaxPrice('');
    setConditionFilter('all');
    setCampusFilter('All Campuses');
    setSearchQuery('');
  };

  const filteredListings = useMemo(() => {
    return listings.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      // Condition filter
      if (conditionFilter !== 'all' && item.condition !== conditionFilter) {
        return false;
      }
      // Campus filter
      if (campusFilter !== 'All Campuses' && item.campus !== campusFilter) {
        return false;
      }
      // Min price
      if (minPrice && item.price < parseFloat(minPrice)) {
        return false;
      }
      // Max price
      if (maxPrice && item.price > parseFloat(maxPrice)) {
        return false;
      }
      // Search term
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = item.title.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        const matchesLocation = item.location.toLowerCase().includes(query);
        const matchesSeller = item.sellerName.toLowerCase().includes(query);
        const matchesCampus = item.campus.toLowerCase().includes(query);
        if (!matchesTitle && !matchesDesc && !matchesLocation && !matchesSeller && !matchesCampus) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      return 0; // default newest
    });
  }, [listings, selectedCategory, conditionFilter, campusFilter, minPrice, maxPrice, searchQuery, sortBy]);

  return (
    <div className="space-y-8 pt-4 pb-16">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-stone-200/80 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase font-semibold tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200/60">
              Maseno University Marketplace
            </span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
            Browse listings
          </h1>
          <p className="text-stone-500 text-sm mt-1 font-light">
            {filteredListings.length} {filteredListings.length === 1 ? 'listing' : 'listings'} available across campus
          </p>
        </div>

        {/* Top actions & Sorting */}
        <div className="flex items-center gap-3">
          {/* Mobile filter toggle */}
          <button
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="md:hidden flex items-center gap-1.5 px-3.5 py-2 bg-white border border-stone-200 rounded-full text-xs font-medium text-stone-700 cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>

          {/* Sort dropdown */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="appearance-none bg-white border border-stone-200/90 rounded-full px-4 py-2 pr-9 text-xs sm:text-sm text-stone-700 hover:border-stone-300 focus:outline-none focus:ring-1 focus:ring-[#0f382c] cursor-pointer shadow-2xs font-normal"
            >
              <option value="newest">Newest first</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-stone-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Main Grid: Left Filters Sidebar + Right Listings Feed */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        {/* Left Filter Sidebar */}
        <aside className={`md:col-span-4 lg:col-span-3 space-y-6 ${mobileFilterOpen ? 'block' : 'hidden md:block'}`}>
          <div className="bg-white rounded-3xl p-5 border border-stone-200/80 space-y-6 shadow-2xs">
            {/* MASENO CAMPUS SELECTOR */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                MASENO CAMPUS
              </span>
              <div className="relative">
                <select
                  value={campusFilter}
                  onChange={(e) => setCampusFilter(e.target.value)}
                  className="w-full appearance-none bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 pr-8 text-xs text-stone-800 focus:outline-none focus:border-stone-400 cursor-pointer font-medium"
                >
                  {MASENO_CAMPUSES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <School className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* CATEGORIES */}
            <div className="border-t border-stone-100 pt-5 space-y-3">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                CATEGORIES
              </span>
              <div className="space-y-1">
                {/* All categories option */}
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`w-full flex items-center justify-between px-3.5 py-2 rounded-2xl text-xs sm:text-sm transition text-left cursor-pointer ${
                    selectedCategory === 'all'
                      ? 'bg-stone-100/90 text-stone-900 font-semibold'
                      : 'text-stone-600 hover:bg-stone-50 hover:text-stone-900'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    All categories
                  </span>
                  <span className="text-xs text-stone-400">{listings.length}</span>
                </button>

                {/* Specific categories */}
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2 rounded-2xl text-xs sm:text-sm transition text-left cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-emerald-50 text-[#0f382c] font-semibold border border-emerald-200/60'
                        : 'text-stone-600 hover:bg-stone-50 hover:text-stone-900'
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      {getCategoryIcon(cat.id)}
                      <span>{cat.name}</span>
                    </span>
                    <span className="text-xs text-stone-400">
                      {listings.filter((l) => l.category === cat.id).length}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* PRICE RANGE (KSH) */}
            <div className="border-t border-stone-100 pt-5 space-y-3">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                PRICE RANGE (KSH)
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  placeholder="Min"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50/50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 focus:outline-none focus:border-stone-400"
                />
                <span className="text-stone-400 text-xs">—</span>
                <input
                  type="number"
                  placeholder="Max"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50/50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 focus:outline-none focus:border-stone-400"
                />
              </div>
            </div>

            {/* CONDITION */}
            <div className="border-t border-stone-100 pt-5 space-y-3">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                CONDITION
              </span>
              <div className="relative">
                <select
                  value={conditionFilter}
                  onChange={(e) => setConditionFilter(e.target.value)}
                  className="w-full appearance-none bg-stone-50/50 border border-stone-200 rounded-xl px-3 py-2 pr-8 text-xs sm:text-sm text-stone-800 focus:outline-none focus:border-stone-400 cursor-pointer"
                >
                  <option value="all">Any condition</option>
                  <option value="Brand New">Brand New</option>
                  <option value="Like New">Like New</option>
                  <option value="Good">Good</option>
                  <option value="Fair">Fair</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* Reset filters button */}
            <div className="pt-2">
              <button
                onClick={resetFilters}
                className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium text-stone-600 hover:text-stone-900 border border-stone-200 hover:bg-stone-50 rounded-xl transition cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset filters</span>
              </button>
            </div>
          </div>
        </aside>

        {/* Right Listings Container */}
        <div className="md:col-span-8 lg:col-span-9">
          {/* Active search filter pills bar */}
          {(searchQuery || selectedCategory !== 'all' || conditionFilter !== 'all' || campusFilter !== 'All Campuses' || minPrice || maxPrice) && (
            <div className="mb-4 flex flex-wrap items-center gap-2 text-xs text-stone-600">
              <span className="text-stone-400">Active filters:</span>
              {searchQuery && (
                <span className="bg-emerald-50 text-emerald-900 border border-emerald-200/80 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                  Search: "{searchQuery}"
                  <button onClick={() => setSearchQuery('')} className="hover:text-stone-900 font-bold cursor-pointer">×</button>
                </span>
              )}
              {campusFilter !== 'All Campuses' && (
                <span className="bg-emerald-50 text-emerald-900 border border-emerald-200/80 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                  Campus: {campusFilter}
                  <button onClick={() => setCampusFilter('All Campuses')} className="hover:text-stone-900 font-bold cursor-pointer">×</button>
                </span>
              )}
              {selectedCategory !== 'all' && (
                <span className="bg-emerald-50 text-emerald-900 border border-emerald-200/80 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                  Category: {categories.find((c) => c.id === selectedCategory)?.name || selectedCategory}
                  <button onClick={() => setSelectedCategory('all')} className="hover:text-stone-900 font-bold cursor-pointer">×</button>
                </span>
              )}
              {conditionFilter !== 'all' && (
                <span className="bg-emerald-50 text-emerald-900 border border-emerald-200/80 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                  Condition: {conditionFilter}
                  <button onClick={() => setConditionFilter('all')} className="hover:text-stone-900 font-bold cursor-pointer">×</button>
                </span>
              )}
              {(minPrice || maxPrice) && (
                <span className="bg-emerald-50 text-emerald-900 border border-emerald-200/80 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                  KSh {minPrice || '0'} – {maxPrice || '∞'}
                  <button onClick={() => { setMinPrice(''); setMaxPrice(''); }} className="hover:text-stone-900 font-bold cursor-pointer">×</button>
                </span>
              )}
            </div>
          )}

          {/* Listings Feed or Empty State */}
          {filteredListings.length === 0 ? (
            <div className="bg-white rounded-3xl border border-stone-200/80 p-12 sm:p-20 text-center flex flex-col items-center justify-center space-y-4 shadow-2xs">
              <div className="w-14 h-14 rounded-2xl bg-stone-100 flex items-center justify-center text-stone-400">
                <Search className="w-6 h-6 stroke-[1.8]" />
              </div>

              <div className="space-y-1.5 max-w-md">
                <h3 className="font-serif text-2xl sm:text-3xl text-stone-900 font-normal">
                  Nothing matched that search
                </h3>
                <p className="text-stone-500 text-xs sm:text-sm font-light leading-relaxed">
                  Try a different keyword, widen your price range, or clear the filters to see all Maseno listings.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                <button
                  onClick={resetFilters}
                  className="bg-[#0f382c] hover:bg-[#154637] text-white px-6 py-2.5 rounded-full text-xs sm:text-sm font-medium transition active:scale-95 shadow-xs cursor-pointer"
                >
                  Clear filters
                </button>

                <button
                  onClick={onOpenSellModal}
                  className="inline-flex items-center gap-1.5 border border-stone-200 hover:bg-stone-50 text-stone-700 px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium transition cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Sell an item</span>
                </button>
              </div>
            </div>
          ) : (
            /* Listings Grid */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredListings.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectItem(item)}
                  className="group cursor-pointer bg-white rounded-3xl border border-stone-200/90 overflow-hidden hover:border-emerald-400 hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
                >
                  <div>
                    {/* Item Image */}
                    <div className="aspect-[4/3] relative bg-stone-100 overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.pexels.com/photos/34889792/pexels-photo-34889792.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";
                        }}
                      />
                      {/* Price Badge */}
                      <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-semibold text-stone-900 shadow-sm border border-stone-100">
                        KSh {item.price.toLocaleString()}
                      </div>
                      {/* Condition Badge */}
                      <div className="absolute bottom-3 left-3 bg-[#0f382c]/90 text-white backdrop-blur-xs px-2.5 py-0.5 rounded-lg text-[11px] font-medium shadow-2xs">
                        {item.condition}
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-4 space-y-2">
                      <div className="text-[11px] text-emerald-800 font-medium">
                        {item.campus}
                      </div>
                      <h3 className="font-serif text-[17px] font-medium text-stone-900 group-hover:text-[#0f382c] transition line-clamp-1">
                        {item.title}
                      </h3>
                      <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed font-light">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  {/* Footer details */}
                  <div className="px-4 pb-4 pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 text-stone-500 truncate max-w-[150px]">
                      <MapPin className="w-3.5 h-3.5 shrink-0 text-stone-400" />
                      <span className="truncate">{item.location}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      {item.sellerVerified && (
                        <span title="Verified Maseno student seller">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        </span>
                      )}
                      <span className="text-stone-700 font-medium text-[11px]">{item.sellerName}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
