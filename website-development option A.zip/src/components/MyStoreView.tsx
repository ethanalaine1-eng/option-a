import React from 'react';
import { 
  Plus, 
  Package, 
  Clock, 
  CheckCircle, 
  Wallet, 
  Eye, 
  MessageCircle, 
  Trash2, 
  ExternalLink,
  Tag,
  School
} from 'lucide-react';
import { Listing } from '../types';

interface MyStoreViewProps {
  userListings: Listing[];
  onOpenSellModal: () => void;
  onSelectItem: (item: Listing) => void;
  onDeleteListing?: (id: string) => void;
  onToggleStatus?: (id: string) => void;
}

export const MyStoreView: React.FC<MyStoreViewProps> = ({
  userListings,
  onOpenSellModal,
  onSelectItem,
  onDeleteListing,
  onToggleStatus
}) => {
  const liveCount = userListings.filter(l => l.status === 'active').length;
  const newRequestsCount = 0;
  const completedDealsCount = 0;
  const totalEarned = 0;

  return (
    <div className="space-y-10 pt-4 pb-16">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-stone-200/80 pb-6">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-medium mb-1">
            <School className="w-3.5 h-3.5 text-emerald-700" />
            <span>Maseno University Student Vendor Dashboard</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#143d31] font-normal tracking-tight">
            My store
          </h1>
          <p className="text-stone-500 text-sm mt-1 font-light">
            Post new items, keep prices current and track what Maseno students are asking for.
          </p>
        </div>

        <button
          onClick={onOpenSellModal}
          className="inline-flex items-center gap-2 bg-[#0f382c] hover:bg-[#154637] text-white px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium transition active:scale-95 shadow-xs shrink-0 self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New listing</span>
        </button>
      </div>

      {/* 4 Stat Cards matching Screenshot 9 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: LIVE LISTINGS */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
              LIVE LISTINGS
            </span>
            <Package className="w-4 h-4 stroke-[1.8] text-stone-400" />
          </div>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {liveCount}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Visible to buyers in Maseno
          </div>
        </div>

        {/* Card 2: NEW REQUESTS */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
              NEW REQUESTS
            </span>
            <Clock className="w-4 h-4 stroke-[1.8] text-stone-400" />
          </div>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {newRequestsCount}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Waiting for your reply
          </div>
        </div>

        {/* Card 3: COMPLETED */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
              COMPLETED
            </span>
            <CheckCircle className="w-4 h-4 stroke-[1.8] text-stone-400" />
          </div>
          <div className="font-serif text-3xl sm:text-4xl text-[#143d31] my-2 font-normal">
            {completedDealsCount}
          </div>
          <div className="text-xs text-stone-400 font-light">
            Deals closed on campus
          </div>
        </div>

        {/* Card 4: EARNED */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200/80 flex flex-col justify-between shadow-2xs min-h-[140px]">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-[11px] font-semibold tracking-wider uppercase text-stone-500">
              EARNED
            </span>
            <Wallet className="w-4 h-4 stroke-[1.8] text-stone-400" />
          </div>
          <div className="font-serif text-2xl sm:text-3xl text-[#143d31] my-2 font-normal tracking-tight">
            KSh {totalEarned.toLocaleString()}
          </div>
          <div className="text-xs text-stone-400 font-light">
            From completed orders
          </div>
        </div>
      </div>

      {/* Your Listings Section */}
      <div className="space-y-4">
        <h2 className="font-serif text-2xl text-stone-900 font-normal">
          Your listings
        </h2>

        {userListings.length === 0 ? (
          /* Empty state matching Screenshot 9 */
          <div className="bg-white rounded-3xl border border-stone-200/80 p-16 sm:p-24 text-center flex flex-col items-center justify-center space-y-4 shadow-2xs">
            <div className="w-14 h-14 rounded-2xl bg-stone-100 flex items-center justify-center text-stone-400">
              <Package className="w-6 h-6 stroke-[1.8]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-serif text-2xl text-stone-800 font-normal">
                You have not posted anything yet
              </h3>
              <p className="text-xs sm:text-sm text-stone-400 font-light max-w-sm mx-auto">
                Got old MAT revision guides, spare chargers, campus thrift, or hostel spaces in Sunrise? Sell to fellow Maseno students.
              </p>
            </div>
            <div className="pt-2">
              <button
                onClick={onOpenSellModal}
                className="inline-flex items-center gap-2 bg-[#0f382c] hover:bg-[#154637] text-white px-6 py-2.5 rounded-full text-xs sm:text-sm font-medium transition active:scale-95 shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create first listing</span>
              </button>
            </div>
          </div>
        ) : (
          /* Populated listings in store */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {userListings.map((listing) => (
              <div 
                key={listing.id}
                className="bg-white rounded-3xl border border-stone-200/80 overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-[16/9] relative bg-stone-100">
                    <img
                      src={listing.image}
                      alt={listing.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3 bg-white/95 px-2.5 py-1 rounded-full text-xs font-semibold text-stone-900 shadow-xs">
                      KSh {listing.price.toLocaleString()}
                    </div>
                    <div className={`absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[11px] font-medium shadow-xs ${
                      listing.status === 'active' 
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-stone-200 text-stone-700'
                    }`}>
                      {listing.status === 'active' ? 'Active' : 'Sold'}
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <div className="text-[11px] text-emerald-800 font-medium">
                      {listing.campus}
                    </div>
                    <h3 className="font-serif text-base font-medium text-stone-900 line-clamp-1">
                      {listing.title}
                    </h3>
                    <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                      {listing.description}
                    </p>

                    <div className="flex items-center gap-4 text-xs text-stone-400 pt-2">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5" />
                        {listing.views || 0} views
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-3.5 h-3.5" />
                        {listing.inquiries || 0} inquiries
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-4 pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                  <button
                    onClick={() => onSelectItem(listing)}
                    className="inline-flex items-center gap-1 text-[#0f382c] hover:underline font-medium cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>View item</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {onToggleStatus && (
                      <button
                        onClick={() => onToggleStatus(listing.id)}
                        className="px-2.5 py-1 text-stone-600 hover:bg-stone-100 rounded-lg transition text-[11px] border border-stone-200 cursor-pointer"
                      >
                        {listing.status === 'active' ? 'Mark Sold' : 'Reactivate'}
                      </button>
                    )}

                    {onDeleteListing && (
                      <button
                        onClick={() => onDeleteListing(listing.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                        title="Delete listing"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Seller Tips Card */}
      <div className="bg-stone-100/70 rounded-3xl p-6 border border-stone-200/80 flex flex-col sm:flex-row items-center gap-6 justify-between">
        <div className="space-y-1">
          <h4 className="font-serif text-lg text-stone-900 font-normal">
            Need faster sales at Maseno?
          </h4>
          <p className="text-xs text-stone-500">
            Meetups scheduled at Millennium Library steps, Siriba Mess, or College Campus common room close deals within 24 hours.
          </p>
        </div>
        <button
          onClick={onOpenSellModal}
          className="inline-flex items-center gap-2 bg-white text-stone-800 border border-stone-200 hover:bg-stone-50 px-4 py-2 rounded-full text-xs font-medium shrink-0 transition cursor-pointer"
        >
          <Tag className="w-3.5 h-3.5 text-stone-500" />
          <span>Post another item</span>
        </button>
      </div>
    </div>
  );
};
