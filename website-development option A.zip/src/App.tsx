import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { BrowseView } from './components/BrowseView';
import { MyStoreView } from './components/MyStoreView';
import { OrdersView } from './components/OrdersView';
import { MessagesView } from './components/MessagesView';
import { NewListingModal } from './components/NewListingModal';
import { ItemDetailModal } from './components/ItemDetailModal';
import { AdminPortalModal } from './components/AdminPortalModal';
import { VerificationModal } from './components/VerificationModal';
import { ProfileView } from './components/ProfileView';
import { AuthModal } from './components/AuthModal';
import { LoginPage } from './components/LoginPage';
import { ReportProblemModal } from './components/ReportProblemModal';
import { SafetyTipsModal } from './components/SafetyTipsModal';
import { AdminView } from './components/AdminView';
import { 
  INITIAL_CATEGORIES, 
  INITIAL_ORDERS, 
  INITIAL_CONVERSATIONS,
  DEFAULT_USER_PROFILE 
} from './data/mockData';
import { Listing, OrderItem, Conversation, Category, UserProfile } from './types';
import { CheckCircle2, School } from 'lucide-react';

export function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'browse' | 'store' | 'messages' | 'orders' | 'admin' | 'profile' | 'login'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedCampus, setSelectedCampus] = useState<string>('All Campuses');

  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [authRedirectReason, setAuthRedirectReason] = useState<string | null>(null);
  
  // Multiple users support so every user can have their own account
  const [usersList, setUsersList] = useState<UserProfile[]>([
    DEFAULT_USER_PROFILE,
    {
      id: 'user-brian-2',
      name: 'Brian Otieno',
      regNumber: 'ED/00234/022',
      university: 'Maseno University',
      campus: 'College Campus',
      department: 'School of Education',
      email: 'brian.otieno@student.maseno.ac.ke',
      phone: '0722 111 222',
      defaultMeetup: 'College Campus Common Room',
      bio: 'Third-year Education Arts student. Passionate about study materials and campus electronics.',
      isVerified: false,
      verificationRequested: false,
      memberSince: 'October 2023',
      totalDeals: 0,
      rating: 4.8,
      listingsCount: 0,
      savedCount: 0
    }
  ]);

  const [currentUserId, setCurrentUserId] = useState<string>(DEFAULT_USER_PROFILE.id);
  const currentUser = isLoggedIn ? (usersList.find(u => u.id === currentUserId) || usersList[0]) : null;

  // Clean zero-listings state
  const [listings, setListings] = useState<Listing[]>([]);
  const [userListings, setUserListings] = useState<Listing[]>([]);
  const [orders, setOrders] = useState<OrderItem[]>(INITIAL_ORDERS);
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);

  // Modals state
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isSafetyTipsModalOpen, setIsSafetyTipsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Listing | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Helper to enforce login before executing an action
  const requireAuth = (action: () => void, reason: string) => {
    if (!isLoggedIn || !currentUser) {
      setAuthRedirectReason(reason);
      setActiveTab('login');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast(`Please log in first: ${reason}`);
      return false;
    }
    action();
    return true;
  };

  // Categories with live dynamic counts
  const categoriesWithCounts: Category[] = INITIAL_CATEGORIES.map((cat) => ({
    ...cat,
    count: listings.filter((l) => l.category === cat.id).length
  }));

  // Handlers
  const handleSelectCategoryFromHome = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setActiveTab('browse');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleHeroSearch = (term: string) => {
    setSearchQuery(term);
    setActiveTab('browse');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenSell = () => {
    requireAuth(() => {
      setIsSellModalOpen(true);
    }, 'You must be logged in to post an item for sale on Soko Maseno.');
  };

  const handleCreateListing = (newListing: Listing) => {
    if (!currentUser) return;
    const listingWithCurrentSeller = {
      ...newListing,
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerVerified: currentUser.isVerified,
      campus: currentUser.campus
    };
    setListings(prev => [listingWithCurrentSeller, ...prev]);
    setUserListings(prev => [listingWithCurrentSeller, ...prev]);
    showToast(`"${listingWithCurrentSeller.title}" posted to Soko Maseno!`);
  };

  const handleDeleteListing = (id: string) => {
    setListings(prev => prev.filter(l => l.id !== id));
    setUserListings(prev => prev.filter(l => l.id !== id));
    showToast('Listing removed from your store.');
  };

  const handleToggleListingStatus = (id: string) => {
    const update = (list: Listing[]) =>
      list.map(l => l.id === id ? { ...l, status: l.status === 'active' ? 'sold' : 'active' } as Listing : l);
    setListings(update);
    setUserListings(update);
    showToast('Listing status updated.');
  };

  const handleRequestBuy = (item: Listing, quantity: number) => {
    requireAuth(() => {
      if (!currentUser) return;
      const newOrder: OrderItem = {
        id: 'ord-' + Date.now(),
        title: item.title,
        type: 'buying',
        status: 'Pending',
        date: 'Just now',
        sellerName: item.sellerName,
        buyerName: currentUser.name,
        quantity,
        unitPrice: item.price,
        totalPrice: item.price * quantity,
        meetupLocation: item.location,
        image: item.image
      };

      setOrders(prev => [newOrder, ...prev]);
      showToast(`Order request sent for ${quantity}x ${item.title}!`);
    }, 'You must be logged in to request and buy items on Soko Maseno.');
  };

  const handleOpenChatWithSeller = (sellerName: string, itemTitle: string) => {
    requireAuth(() => {
      if (!currentUser) return;
      let existing = conversations.find(c => c.participantName.toLowerCase() === sellerName.toLowerCase());
      if (!existing) {
        const newConv: Conversation = {
          id: 'conv-' + Date.now(),
          participantName: sellerName,
          participantRole: 'Maseno Student Seller',
          itemTitle,
          itemPrice: 1500,
          lastMessage: 'Hi, I am interested in this item!',
          lastMessageTime: 'Just now',
          unreadCount: 0,
          messages: [
            {
              id: 'm-' + Date.now(),
              senderId: currentUser.id,
              senderName: currentUser.name,
              text: `Hi ${sellerName}! I saw your listing for "${itemTitle}" on Soko Maseno. Can we meet at ${currentUser.defaultMeetup}?`,
              timestamp: 'Just now',
              isMe: true
            }
          ]
        };
        setConversations(prev => [newConv, ...prev]);
      }
      setActiveTab('messages');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 'You must be logged in to message campus sellers.');
  };

  const handleSendMessage = (convId: string, text: string) => {
    if (!currentUser) return;
    setConversations(prev => prev.map(conv => {
      if (conv.id === convId) {
        const newMsg = {
          id: 'msg-' + Date.now(),
          senderId: currentUser.id,
          senderName: currentUser.name,
          text,
          timestamp: 'Just now',
          isMe: true
        };
        return {
          ...conv,
          lastMessage: text,
          lastMessageTime: 'Just now',
          messages: [...conv.messages, newMsg]
        };
      }
      return conv;
    }));
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderItem['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
    showToast(`Order marked as ${newStatus}.`);
  };

  // User Profile & Authentication Handlers
  const handleUpdateProfile = (updated: UserProfile) => {
    setUsersList(prev => prev.map(u => u.id === updated.id ? updated : u));
    showToast('Profile updated successfully!');
  };

  const handleAccountCreated = (newUser: UserProfile) => {
    setUsersList(prev => [newUser, ...prev]);
    setCurrentUserId(newUser.id);
    setIsLoggedIn(true);
    setAuthRedirectReason(null);
    setActiveTab('profile');
    showToast(`Welcome to Soko Maseno, ${newUser.name}!`);
  };

  const handleLoginSuccess = (user: UserProfile) => {
    if (!usersList.some(u => u.id === user.id)) {
      setUsersList(prev => [user, ...prev]);
    }
    setCurrentUserId(user.id);
    setIsLoggedIn(true);
    setAuthRedirectReason(null);
    setActiveTab('home');
    showToast(`Logged in successfully as ${user.name}`);
  };

  const handleSignOut = () => {
    setIsLoggedIn(false);
    setActiveTab('home');
    showToast('Signed out of Soko Maseno. Log in anytime to buy or sell.');
  };

  const handleSwitchUser = (userId: string) => {
    setCurrentUserId(userId);
    setIsLoggedIn(true);
    const target = usersList.find(u => u.id === userId);
    showToast(`Switched account to ${target?.name || 'Comrade'}`);
  };

  return (
    <div className="min-h-screen bg-[#fbfbf9] text-[#1e2420] flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 sm:right-8 z-50 bg-[#0f382c] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs sm:text-sm animate-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab: string) => {
          if (tab === 'store' || tab === 'profile' || tab === 'orders') {
            requireAuth(() => {
              setActiveTab(tab as any);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }, `You must log in to view ${tab}.`);
          } else {
            setActiveTab(tab as any);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenSellModal={handleOpenSell}
        onOpenAdminModal={() => {
          setActiveTab('admin');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenVerificationModal={() => {
          requireAuth(() => {
            setIsVerificationModalOpen(true);
          }, 'Please log in to submit student verification.');
        }}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        isLoggedIn={isLoggedIn}
        onSignOut={handleSignOut}
        selectedCampus={selectedCampus}
        onSelectCampus={(camp) => {
          setSelectedCampus(camp);
          setActiveTab('browse');
        }}
      />

      {/* Main Page Content */}
      <main className="flex-1 w-full">
        {/* Tab Views */}
        {activeTab === 'home' && (
          <HomeView
            categories={categoriesWithCounts}
            listings={listings}
            onSelectCategory={handleSelectCategoryFromHome}
            onSearch={handleHeroSearch}
            onNavigateToBrowse={() => {
              setActiveTab('browse');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenSellModal={handleOpenSell}
            onOpenVerificationModal={() => {
              requireAuth(() => {
                setIsVerificationModalOpen(true);
              }, 'Please log in to request admin verification.');
            }}
            onSelectItem={(item) => setSelectedItem(item)}
          />
        )}

        {/* LOGIN / REGISTRATION PAGE */}
        {activeTab === 'login' && (
          <LoginPage
            onLoginSuccess={handleLoginSuccess}
            onRegisterSuccess={handleAccountCreated}
            existingUsers={usersList}
            redirectReason={authRedirectReason}
            onCancel={() => {
              setAuthRedirectReason(null);
              setActiveTab('home');
            }}
          />
        )}

        {activeTab !== 'home' && activeTab !== 'login' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-4">
            {/* Maseno University Top Hub Banner */}
            <div className="mb-4 flex flex-wrap items-center justify-between bg-stone-100/80 border border-stone-200/80 px-4 py-2.5 rounded-2xl text-xs text-stone-600 gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-medium text-stone-800 flex items-center gap-1.5">
                  <School className="w-3.5 h-3.5 text-emerald-700" />
                  Soko Maseno Hub:
                </span>
                <span className="text-stone-500">Siriba (Main), College, Kisumu (Varsity Plaza) &amp; Odera Akang'o Campuses</span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-[#0f382c]">
                  {isLoggedIn && currentUser ? (
                    <>Active: <strong className="text-stone-900">{currentUser.name}</strong> ({currentUser.campus.split('—')[0].trim()})</>
                  ) : (
                    <button 
                      onClick={() => setActiveTab('login')}
                      className="text-emerald-800 font-semibold underline cursor-pointer"
                    >
                      Sign In to Buy / Sell
                    </button>
                  )}
                </span>
              </div>
            </div>

            {activeTab === 'profile' && currentUser && (
              <ProfileView
                currentUser={currentUser}
                onUpdateProfile={handleUpdateProfile}
                onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
                onOpenAuthModal={() => setIsAuthModalOpen(true)}
                usersList={usersList}
                onSwitchUser={handleSwitchUser}
              />
            )}

            {activeTab === 'browse' && (
              <BrowseView
                categories={categoriesWithCounts}
                listings={listings}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                onSelectItem={(item) => setSelectedItem(item)}
                onOpenSellModal={handleOpenSell}
              />
            )}

            {activeTab === 'store' && (
              <MyStoreView
                userListings={userListings}
                onOpenSellModal={handleOpenSell}
                onSelectItem={(item) => setSelectedItem(item)}
                onDeleteListing={handleDeleteListing}
                onToggleStatus={handleToggleListingStatus}
              />
            )}

            {activeTab === 'orders' && (
              <OrdersView
                orders={orders}
                onOpenChatWithSeller={handleOpenChatWithSeller}
                onUpdateOrderStatus={handleUpdateOrderStatus}
              />
            )}

            {activeTab === 'messages' && (
              <MessagesView
                conversations={conversations}
                onSendMessage={handleSendMessage}
              />
            )}

            {activeTab === 'admin' && (
              <AdminView
                listings={listings}
                orders={orders}
                categories={categoriesWithCounts}
                conversations={conversations}
                onDeleteListing={handleDeleteListing}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer matching user's exact footer layout */}
      <Footer
        setActiveTab={(tab: string) => {
          if (tab === 'store' || tab === 'orders' || tab === 'messages') {
            requireAuth(() => {
              setActiveTab(tab as any);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }, `You must log in to view ${tab}.`);
          } else {
            setActiveTab(tab as any);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }}
        onOpenSellModal={handleOpenSell}
        onOpenAdminModal={() => {
          setActiveTab('admin');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenVerificationModal={() => {
          requireAuth(() => {
            setIsVerificationModalOpen(true);
          }, 'Please log in to submit student verification.');
        }}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        onOpenSafetyTipsModal={() => setIsSafetyTipsModalOpen(true)}
      />

      {/* Modals */}
      <NewListingModal
        isOpen={isSellModalOpen}
        onClose={() => setIsSellModalOpen(false)}
        categories={categoriesWithCounts}
        onSubmitListing={handleCreateListing}
      />

      <ItemDetailModal
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
        onOpenChat={handleOpenChatWithSeller}
        onRequestBuy={handleRequestBuy}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAccountCreated={handleAccountCreated}
        existingUsers={usersList}
        onSwitchUser={handleSwitchUser}
      />

      <AdminPortalModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />

      <VerificationModal
        isOpen={isVerificationModalOpen}
        onClose={() => setIsVerificationModalOpen(false)}
        onRequestSubmitted={(req) => {
          if (currentUser) {
            handleUpdateProfile({
              ...currentUser,
              regNumber: req.studentId,
              verificationRequested: true
            });
          }
          showToast(`Verification requested for ${req.name} (${req.studentId})! Admin notified.`);
        }}
      />

      <ReportProblemModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />

      <SafetyTipsModal
        isOpen={isSafetyTipsModalOpen}
        onClose={() => setIsSafetyTipsModalOpen(false)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
      />
    </div>
  );
}
export default App;
