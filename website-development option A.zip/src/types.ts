export type CategoryId = 
  | 'textbooks'
  | 'electronics'
  | 'fashion'
  | 'food'
  | 'hostels'
  | 'services'
  | 'transport';

export type MasenoCampus = 
  | 'All Campuses'
  | 'Main Campus — Maseno Township'
  | 'Siriba Campus (Main)'
  | 'College Campus'
  | 'Kisumu City Campus (Varsity Plaza)'
  | 'Odera Akang’o Campus';

export interface Category {
  id: CategoryId;
  name: string;
  iconName: string;
  description?: string;
  count: number;
}

export type ItemCondition = 'Brand New' | 'Like New' | 'Good' | 'Fair';

export interface Listing {
  id: string;
  title: string;
  price: number; // In KSh
  category: CategoryId;
  condition: ItemCondition;
  description: string;
  location: string;
  image: string;
  sellerId: string;
  sellerName: string;
  sellerRating: number;
  sellerVerified: boolean;
  campus: string;
  createdAt: string;
  status: 'active' | 'sold' | 'reserved';
  views?: number;
  inquiries?: number;
}

export interface OrderItem {
  id: string;
  title: string;
  type: 'buying' | 'selling';
  status: 'Pending' | 'Accepted' | 'Completed' | 'Cancelled';
  date: string;
  sellerName: string;
  buyerName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  meetupLocation: string;
  image?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  isMe: boolean;
}

export interface Conversation {
  id: string;
  participantName: string;
  participantAvatar?: string;
  participantRole: string;
  itemTitle: string;
  itemPrice: number;
  itemImage?: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  messages: ChatMessage[];
}

export interface UserProfile {
  id: string;
  name: string;
  regNumber?: string;
  university: string;
  campus: string;
  department?: string;
  email: string;
  phone: string;
  defaultMeetup: string;
  bio: string;
  isVerified: boolean;
  verificationRequested?: boolean;
  memberSince: string;
  totalDeals: number;
  rating: number;
  listingsCount?: number;
  savedCount?: number;
}
